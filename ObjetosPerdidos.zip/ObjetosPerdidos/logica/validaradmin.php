<?php
session_start();
require_once __DIR__ . '/../config/conexionBDD.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($usuario) || empty($password)) {
        header('Location: ../vista/loginAdmin.php?error=' . urlencode('Todos los campos son obligatorios.'));
        exit();
    }

    try {
        // Valida el usuario ingresado contra la base de datos
        $stmt = $conexion->prepare("SELECT * FROM usuarios WHERE nombre = :usuario AND rol IN ('Administrador', 'Administrativo') LIMIT 1");
        $stmt->execute([':usuario' => $usuario]);
        
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        // Verifica si existe el registro y la contraseña cifrada coincide
        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin'] = $admin['id'];
            $_SESSION['nombre_admin'] = $admin['nombre'];
            
            header('Location: ../vista/listaEstudiante.php');
            exit();
        } else {
            header('Location: ../vista/loginAdmin.php?error=' . urlencode('Usuario o contraseña incorrectos.'));
            exit();
        }
    } catch (PDOException $e) {
        header('Location: ../vista/loginAdmin.php?error=' . urlencode('Error en el servidor al intentar iniciar sesión.'));
        exit();
    }
} else {
    header('Location: ../vista/loginAdmin.php');
    exit();
}