<?php
if (!function_exists('iniciarSesionSegura')) {
    function iniciarSesionSegura() {
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
    }
}

iniciarSesionSegura();
require_once __DIR__ . '/../config/conexionBDD.php';

$accion = $_POST['accion'] ?? '';

// 1. INICIAR SESIÓN
if ($accion === 'login') {
    $correo = trim($_POST['correo'] ?? '');
    $celular = trim($_POST['celular'] ?? '');

    if (empty($correo) || empty($celular)) {
        header('Location: ../index.php?error=' . urlencode('Por favor completa todos los campos.'));
        exit();
    }

    $sql = "SELECT * FROM usuarios WHERE correo = ? AND celular = ? LIMIT 1";
    $stmt = $conexion->prepare($sql);
    $stmt->execute([$correo, $celular]);
    $usuarioData = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuarioData) {
        $_SESSION['usuario'] = [
            'nombre' => $usuarioData['nombre'],
            'rol'    => $usuarioData['rol'],
            'correo' => $usuarioData['correo'],
            'grado'  => $usuarioData['grado'] ?? $usuarioData['curso'] ?? 'No Aplica',
            'edad'   => $usuarioData['edad'] ?? ''
        ];

        header('Location: ../vista/listaEstudiante.php');
        exit();
    } else {
        header('Location: ../index.php?error=' . urlencode('Datos incorrectos. Verifica tu correo y teléfono.'));
        exit();
    }
}

// 2. REGISTRO DE USUARIO
if ($accion === 'registro') {
    $nombre = trim($_POST['nombre'] ?? '');
    $rol = trim($_POST['rol'] ?? '');
    $grado = ($rol === 'Estudiante') ? trim($_POST['grado'] ?? 'No Aplica') : 'No Aplica';
    $tipo_doc = trim($_POST['tipo_documento'] ?? 'TI');
    $num_id = trim($_POST['numero_documento'] ?? '');
    $edad = intval($_POST['edad'] ?? 0);
    $correo = trim($_POST['correo'] ?? '');
    $celular = trim($_POST['celular'] ?? '');

    if (empty($nombre) || empty($rol) || empty($correo) || empty($celular) || empty($num_id)) {
        header('Location: ../index.php?error=' . urlencode('Por favor completa todos los campos, incluyendo el documento.'));
        exit();
    }

    // Comprobar correo existente
    $sqlCheck = "SELECT * FROM usuarios WHERE correo = ? OR num_id = ? LIMIT 1";
    $stmtCheck = $conexion->prepare($sqlCheck);
    $stmtCheck->execute([$correo, $num_id]);

    if ($stmtCheck->fetch()) {
        header('Location: ../index.php?error=' . urlencode('El correo o el número de documento ya están registrados.'));
        exit();
    }

    try {
        // Intentar inserción adaptada a num_id y tipo_doc
        $sqlInsert = "INSERT INTO usuarios (nombre, rol, grado, tipo_doc, num_id, edad, correo, celular) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmtInsert = $conexion->prepare($sqlInsert);
        $exito = $stmtInsert->execute([$nombre, $rol, $grado, $tipo_doc, $num_id, $edad, $correo, $celular]);
    } catch (PDOException $e) {
        try {
            // Reintento con estructura de respaldo
            $sqlInsert = "INSERT INTO usuarios (nombre, rol, grado, num_id, edad, correo, celular) VALUES (?, ?, ?, ?, ?, ?, ?)";
            $stmtInsert = $conexion->prepare($sqlInsert);
            $exito = $stmtInsert->execute([$nombre, $rol, $grado, $num_id, $edad, $correo, $celular]);
        } catch (PDOException $ex) {
            header('Location: ../index.php?error=' . urlencode('El número de documento ya existe en la base de datos.'));
            exit();
        }
    }

    if ($exito) {
        $_SESSION['usuario'] = [
            'nombre' => $nombre,
            'rol'    => $rol,
            'correo' => $correo,
            'grado'  => $grado,
            'edad'   => $edad
        ];

        header('Location: ../vista/listaEstudiante.php');
        exit();
    } else {
        header('Location: ../index.php?error=' . urlencode('Error al realizar el registro.'));
        exit();
    }
}
?>