
<?php

session_start();

require_once __DIR__ . '/../config/conexionBDD.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $usuario = trim($_POST['usuario'] ?? '');
    $pass = $_POST['password'] ?? '';

    $sql = "SELECT id, usuario, `contraseña`
            FROM administrador
            WHERE usuario = :usuario
            LIMIT 1";

    $stmt = $conexion->prepare($sql);
    $stmt->execute([':usuario' => $usuario]);

    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($admin && password_verify($pass, $admin['contraseña'])) {

        session_regenerate_id(true);

        $_SESSION['admin_logueado'] = true;
        $_SESSION['nombre_admin'] = $admin['usuario'];

        header("Location: ../panel_admin.php");
        exit();

    } else {

        header(
            "Location: ../vista/admin_login.php?error=" .
            urlencode("Usuario o contraseña incorrectos.")
        );
        exit();

    }
}

header("Location: ../vista/admin_login.php");
exit();
