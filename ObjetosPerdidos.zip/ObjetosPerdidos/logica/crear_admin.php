
<?php

require_once __DIR__ . '/../config/conexionBDD.php';

$usuario = 'admin';
$contrasena = 'CAMBIA_ESTA_CLAVE';

$hash = password_hash($contrasena, PASSWORD_DEFAULT);

$sql = "INSERT INTO administrador (usuario, contrasena)
        VALUES (:usuario, :contrasena)";

$stmt = $conexion->prepare($sql);

$stmt->execute([
    ':usuario' => $usuario,
    ':contrasena' => $hash
]);

echo "Administrador creado correctamente.";

?>

 