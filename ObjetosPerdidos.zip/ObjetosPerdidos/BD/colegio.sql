CREATE DATABASE IF NOT EXISTS colegio CHARACTER SET utf8mb4 COLLATE utf8mb4_spanish_ci;
USE colegio;

-- Tabla de Usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) UNIQUE NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    tipo_identificacion VARCHAR(50) NOT NULL,
    numero_identificacion VARCHAR(30) UNIQUE NOT NULL,
    rol VARCHAR(30) NOT NULL,
    grado VARCHAR(10) DEFAULT 'N/A',
    edad INT NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Tabla de Objetos Perdidos y Encontrados
CREATE TABLE IF NOT EXISTS objetos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo_reporte ENUM('Perdido', 'Encontrado') NOT NULL,
    nombre_objeto VARCHAR(100) NOT NULL,
    lugar VARCHAR(150) NOT NULL,
    fecha_suceso DATE NOT NULL,
    descripcion TEXT NOT NULL,
    fecha_reporte TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;