<?php
session_start();
require_once __DIR__ . '/config/conexionBDD.php';

if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit();
}

if (isset($_SESSION['usuario'])) {
    header('Location: vista/listaEstudiante.php');
    exit();
}

$error = $_GET['error'] ?? '';
$mensaje = $_GET['mensaje'] ?? '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenido - Reportes Palermo</title>
    <style>
        :root {
            --azul: #72B4EB;
            --beige: #F3E9D7;
            --rosa: #FF9AA2;
            --verde: #CBE8DA;
        }

        body { 
            font-family: Arial, sans-serif; 
            background-color: var(--beige); 
            margin: 0; 
            padding: 40px 20px; 
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
            box-sizing: border-box;
        }

        .fondo-animado {
            position: fixed;
            top: 0; left: 0;
            width: 100%; height: 100%;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }

        .objeto-escolar {
            position: absolute;
            bottom: -80px;
            font-size: 2.2rem;
            opacity: 0.5;
            animation: flotar 12s infinite linear;
        }

        .obj1 { left: 8%; animation-delay: 0s; animation-duration: 10s; }
        .obj2 { left: 22%; animation-delay: 3s; animation-duration: 12s; }
        .obj3 { left: 40%; animation-delay: 1s; animation-duration: 9s; }
        .obj4 { left: 58%; animation-delay: 5s; animation-duration: 11s; }
        .obj5 { left: 75%; animation-delay: 2s; animation-duration: 13s; }
        .obj6 { left: 88%; animation-delay: 4s; animation-duration: 10s; }

        @keyframes flotar {
            0% { transform: translateY(0) rotate(0deg); opacity: 0; }
            20% { opacity: 0.5; }
            80% { opacity: 0.5; }
            100% { transform: translateY(-110vh) rotate(360deg); opacity: 0; }
        }

        .card-auth {
            width: 100%;
            max-width: 480px;
            background: white;
            padding: 35px 30px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            z-index: 10;
            box-sizing: border-box;
            text-align: center;
        }

        .titulo-bienvenida {
            font-family: Georgia, 'Times New Roman', serif;
            font-size: 2.2rem;
            color: #112233;
            margin: 0 0 8px 0;
        }

        .subtitulo-bienvenida {
            color: #777;
            font-size: 0.95rem;
            margin-bottom: 25px;
            line-height: 1.4;
        }

        .tabs-container {
            display: flex;
            background: #F7F5F0;
            border-radius: 12px;
            padding: 5px;
            margin-bottom: 25px;
        }

        .tab-btn {
            flex: 1;
            padding: 12px;
            border: none;
            background: transparent;
            font-size: 0.95rem;
            font-weight: bold;
            color: #777;
            border-radius: 9px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .tab-btn.active {
            background: white;
            color: #222;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
        }

        .form-container { display: none; text-align: left; }
        .form-container.active { display: block; }
        .grupo { margin-bottom: 16px; }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 6px;
            font-size: 0.88rem;
            color: #444;
        }

        input, select {
            width: 100%;
            padding: 11px 14px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-sizing: border-box;
            font-size: 0.95rem;
            background-color: #fafafa;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--azul);
            background-color: white;
        }

        .btn-submit {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
            color: white;
            margin-top: 10px;
        }

        .btn-login-color { background-color: var(--azul); }
        .btn-register-color { background-color: var(--rosa); }

        .alerta-error {
            background-color: #FFEBEE;
            color: #C62828;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            text-align: center;
        }

        .alerta-exito {
            background-color: var(--verde);
            color: #2E7D32;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.9rem;
            text-align: center;
            font-weight: bold;
        }

        .card-footer {
            margin-top: 25px;
            font-size: 0.85rem;
            color: #888;
            border-top: 1px dashed #eee;
            padding-top: 15px;
        }
    </style>
</head>
<body>

<div class="fondo-animado">
    <span class="objeto-escolar obj1">✏️</span>
    <span class="objeto-escolar obj2">📐</span>
    <span class="objeto-escolar obj3">🎒</span>
    <span class="objeto-escolar obj4">📚</span>
    <span class="objeto-escolar obj5">✂️</span>
    <span class="objeto-escolar obj6">🎨</span>
</div>

<div class="card-auth">
    <h1 class="titulo-bienvenida">Reportes Palermo ♡</h1>
    <p class="subtitulo-bienvenida">Tu espacio seguro para reportar y recuperar objetos dentro del colegio.</p>

    <?php if ($error): ?>
        <div class="alerta-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <?php if ($mensaje): ?>
        <div class="alerta-exito"><?php echo htmlspecialchars($mensaje); ?></div>
    <?php endif; ?>

    <div class="tabs-container">
        <button id="btnTabLogin" class="tab-btn" onclick="cambiarTab('login')">Iniciar Sesión</button>
        <button id="btnTabRegister" class="tab-btn active" onclick="cambiarTab('register')">Registrarse</button>
    </div>

    <!-- Formulario de Iniciar Sesión -->
    <div id="formLogin" class="form-container">
        <form action="logica/validarEstudiante.php" method="POST">
            <input type="hidden" name="accion" value="login">

            <div class="grupo">
                <label>Correo Electrónico:</label>
                <input type="email" name="correo" placeholder="correo@ejemplo.com" required>
            </div>

            <div class="grupo">
                <label>Número de Celular (Contraseña):</label>
                <input type="password" name="celular" placeholder="Ej: 3001234567" required>
            </div>

            <button type="submit" class="btn-submit btn-login-color">Ingresar a mi Cuenta</button>
        </form>
    </div>

    <!-- Formulario de Registro -->
    <div id="formRegister" class="form-container active">
        <form action="logica/validarEstudiante.php" method="POST">
            <input type="hidden" name="accion" value="registro">

            <div class="grupo">
                <label>Nombre Completo:</label>
                <input type="text" name="nombre" placeholder="Ej: Miguel Ángel Pérez" required>
            </div>

            <div class="grupo">
                <label>Rol en la Institución:</label>
                <select name="rol" id="rolSelectIndex" onchange="toggleGradoIndex()" required>
                    <option value="Estudiante">Estudiante</option>
                    <option value="Docente">Docente / Profesor(a)</option>
                    <option value="Aseadora">Aseador(a)</option>
                    <option value="Guardia">Guardia</option>
                    <option value="Otro">Otro Miembro</option>
                </select>
            </div>

            <!-- Campo de Grado Separado -->
            <div class="grupo" id="grupoGradoIndex">
                <label>Grado:</label>
                <select name="grado">
                    <option value="No Aplica">No Aplica</option>
                    <option value="6°">6°</option>
                    <option value="7°">7°</option>
                    <option value="8°">8°</option>
                    <option value="9°">9°</option>
                    <option value="10°">10°</option>
                    <option value="11°">11°</option>
                </select>
            </div>

            <!-- Campo de Curso Separado -->
            <div class="grupo" id="grupoCursoIndex">
                <label>Curso:</label>
                <select name="curso">
                    <option value="No Aplica">No Aplica</option>
                    <option value="01">01</option>
                    <option value="02">02</option>
                    <option value="03">03</option>
                </select>
            </div>

            <div class="grupo">
                <label>Tipo de Documento:</label>
                <select name="tipo_documento" required>
                    <option value="TI">Tarjeta de Identidad (TI)</option>
                    <option value="CC">Cédula de Ciudadanía (CC)</option>
                    <option value="CE">Cédula de Extranjería (CE)</option>
                    <option value="PEP">PEP / PPT</option>
                </select>
            </div>

            <div class="grupo">
                <label>Número de Documento:</label>
                <input type="text" name="numero_documento" placeholder="Ej: 1012345678" required>
            </div>

            <div class="grupo">
                <label>Edad (Años):</label>
                <input type="number" name="edad" placeholder="Ej: 15" min="5" max="99" required>
            </div>

            <div class="grupo">
                <label>Correo Electrónico:</label>
                <input type="email" name="correo" placeholder="correo@ejemplo.com" required>
            </div>

            <div class="grupo">
                <label>Número de Celular:</label>
                <input type="tel" name="celular" placeholder="Ej: 3001234567" required>
            </div>

            <button type="submit" class="btn-submit btn-register-color">Crear mi Cuenta</button>
        </form>
    </div>

    <!-- Botón de Administrador ubicado al final -->
    <div style="margin-top: 20px; text-align: center;">
        <a href="vista/admin_login.php" style="font-size: 0.85rem; color: #555; text-decoration: none; background: #eee; padding: 8px 15px; border-radius: 8px; display: inline-block; transition: background 0.2s;">
            🔒 Panel de Administrador
        </a>
    </div>

    <div class="card-footer">
        Colegio Técnico Palermo &bull; Gestión Transparente de Objetos
    </div>
</div>

<script>
    function cambiarTab(tab) {
        var formLogin = document.getElementById('formLogin');
        var formRegister = document.getElementById('formRegister');
        var btnLogin = document.getElementById('btnTabLogin');
        var btnRegister = document.getElementById('btnTabRegister');

        if (tab === 'login') {
            formLogin.classList.add('active');
            formRegister.classList.remove('active');
            btnLogin.classList.add('active');
            btnRegister.classList.remove('active');
        } else {
            formRegister.classList.add('active');
            formLogin.classList.remove('active');
            btnRegister.classList.add('active');
            btnLogin.classList.remove('active');
        }
    }

    function toggleGradoIndex() {
        var rol = document.getElementById('rolSelectIndex').value;
        var mostrar = (rol === 'Estudiante') ? 'block' : 'none';
        
        // Muestra u oculta ambos selectores al cambiar el rol
        document.getElementById('grupoGradoIndex').style.display = mostrar;
        document.getElementById('grupoCursoIndex').style.display = mostrar;
    }

    document.addEventListener('DOMContentLoaded', toggleGradoIndex);
</script>

</body>
</html>