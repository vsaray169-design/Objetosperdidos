// JS/main.js
document.addEventListener('DOMContentLoaded', function() {
    const formRegistro = document.getElementById('formRegistro');

    if (formRegistro) {
        formRegistro.addEventListener('submit', function(e) {
            const nombre = document.getElementById('Nombre').value.trim();
            const correo = document.getElementById('Correo').value.trim();

            // 1. Validar que el nombre NO tenga números
            const regexSoloLetras = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/;
            if (!regexSoloLetras.test(nombre)) {
                alert('El Nombre Completo no debe contener números ni caracteres especiales.');
                e.preventDefault();
                return;
            }

            // 2. Validar que el correo contenga '@'
            if (!correo.includes('@')) {
                alert('Por favor ingrese un correo electrónico válido con @.');
                e.preventDefault();
                return;
            }
        });
    }
});