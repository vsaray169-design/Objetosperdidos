
<?php
session_start();

if (
    !isset($_SESSION['admin_logueado']) ||
    $_SESSION['admin_logueado'] !== true
) {
    header("Location: index.php");
    exit();
}

require_once __DIR__ . '/config/conexionBDD.php';

$mensajeAdmin = $_SESSION['mensaje_admin'] ?? '';
unset($_SESSION['mensaje_admin']);

function e($valor): string
{
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}

function obtenerRutaImagen(array $objeto): string
{
    foreach ([
        'imagen', 'foto', 'ruta_imagen', 'imagen_objeto',
        'foto_objeto', 'imagen_reporte', 'ruta_foto', 'archivo_imagen'
    ] as $columna) {
        if (empty($objeto[$columna]) || !is_string($objeto[$columna])) {
            continue;
        }

        $ruta = str_replace('\\', '/', trim($objeto[$columna]));

        if (preg_match('/^(javascript|data):/i', $ruta)) {
            continue;
        }

        foreach (['/uploads/', '/imagenes/', '/images/', '/reportes/'] as $carpeta) {
            $posicion = stripos($ruta, $carpeta);

            if ($posicion !== false) {
                return substr($ruta, $posicion + 1);
            }
        }

        return ltrim(preg_replace('#^(\.\./|./)+#', '', $ruta), '/');
    }

    return '';
}

/* ==========================================
   PROCESAR FORMULARIOS DEL ADMINISTRADOR
   ========================================== */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /* CAMBIAR ESTADO DE COINCIDENCIA */
    if (isset($_POST['cambiar_estado'])) {
        $id = (int)($_POST['id_reporte'] ?? 0);
        $estado = (string)($_POST['nuevo_estado'] ?? '');

        if (
            $id > 0 &&
            in_array($estado, ['rojo', 'amarillo', 'naranja'], true)
        ) {
            $stmt = $conexion->prepare(
                "UPDATE reportes
                 SET estado_coincidencia = ?
                 WHERE id = ? AND estado_historial = 'activo'"
            );
            $stmt->execute([$estado, $id]);
        }

        header("Location: panel_admin.php");
        exit();
    }

    /* REGISTRAR ENTREGA A CUALQUIER USUARIO REGISTRADO */
    if (isset($_POST['marcar_entregado'])) {
        $idReporte = (int)($_POST['id_reporte'] ?? 0);
        $idUsuario = (int)($_POST['usuario_recibe'] ?? 0);

        try {
            if ($idReporte <= 0 || $idUsuario <= 0) {
                throw new RuntimeException(
                    'Selecciona un estudiante registrado.'
                );
            }

            /* Buscar los datos reales del estudiante */
            $stmtUsuario = $conexion->prepare(
                "SELECT id, nombre, rol, grado, tipo_documento,
                        numero_documento, tipo_id, num_id
                 FROM usuarios
                 WHERE id = ?
                 LIMIT 1"
            );
            $stmtUsuario->execute([$idUsuario]);
            $usuario = $stmtUsuario->fetch(PDO::FETCH_ASSOC);

            if (!$usuario) {
                throw new RuntimeException(
                    'El usuario seleccionado no existe.'
                );
            }

            $nombre = trim((string)$usuario['nombre']);
            $curso = trim((string)($usuario['grado'] ?? ''));

            /* Usar los datos de documento disponibles en usuarios */
            $tipoDocumento = trim((string)(
                !empty($usuario['tipo_documento'])
                    ? $usuario['tipo_documento']
                    : ($usuario['tipo_id'] ?? '')
            ));

            $numeroDocumento = trim((string)(
                !empty($usuario['numero_documento'])
                    ? $usuario['numero_documento']
                    : ($usuario['num_id'] ?? '')
            ));

            if ($nombre === '') {
                throw new RuntimeException(
                    'El usuario no tiene un nombre registrado.'
                );
            }

            /* Solo se entrega un objeto activo con coincidencia */
            $stmtEntrega = $conexion->prepare(
                "UPDATE reportes
                 SET nombre_recibio = ?,
                     curso_recibio = ?,
                     tipo_documento_recibio = ?,
                     numero_documento_recibio = ?,
                     fecha_entrega = NOW(),
                     estado_historial = 'archivado'
                 WHERE id = ?
                   AND estado_historial = 'activo'
                   AND estado_coincidencia = 'naranja'"
            );

            $stmtEntrega->execute([
                $nombre,
                $curso,
                $tipoDocumento,
                $numeroDocumento,
                $idReporte
            ]);

            if ($stmtEntrega->rowCount() > 0) {
                $_SESSION['mensaje_admin'] =
                    'Entrega registrada para ' . $nombre .
                    '. El objeto se trasladó al historial.';
            } else {
                $_SESSION['mensaje_admin'] =
                    'No se registró la entrega. Comprueba que el objeto esté activo y tenga coincidencia naranja.';
            }
        } catch (RuntimeException $ex) {
            $_SESSION['mensaje_admin'] = $ex->getMessage();
        } catch (PDOException $ex) {
            error_log('Error al registrar entrega: ' . $ex->getMessage());
            $_SESSION['mensaje_admin'] =
                'Error de base de datos al registrar la entrega. Revisa la estructura de las tablas.';
        }

        header("Location: panel_admin.php");
        exit();
    }

    /* ATENDER RECLAMACIÓN */
    if (isset($_POST['marcar_reclamo_atendido'])) {
        $idSolicitud = (int)($_POST['id_solicitud'] ?? 0);

        try {
            if ($idSolicitud <= 0) {
                throw new RuntimeException('Solicitud no válida.');
            }

            $stmt = $conexion->prepare(
                "UPDATE solicitudes_reclamo
                 SET estado = 'Atendida',
                     estudiante_recibio =
                         COALESCE(NULLIF(nombre_reclamante, ''), nombre_usuario),
                     fecha_entrega = NOW()
                 WHERE id = ? AND estado = 'Pendiente'"
            );

            $stmt->execute([$idSolicitud]);

            $_SESSION['mensaje_admin'] = $stmt->rowCount() > 0
                ? 'Reclamación atendida y fecha registrada.'
                : 'La reclamación ya fue atendida o no existe.';
        } catch (PDOException $ex) {
            error_log('Error en reclamación: ' . $ex->getMessage());
            $_SESSION['mensaje_admin'] =
                'No se pudo actualizar la reclamación. Revisa las columnas de la tabla.';
        }

        header("Location: panel_admin.php#reclamaciones");
        exit();
    }
}

/* ==========================================
   CONSULTAR REPORTES
   ========================================== */

$stmt = $conexion->query(
    "SELECT * FROM reportes
     WHERE tipo_reporte = 'Perdido'
       AND estado_historial = 'activo'
     ORDER BY id DESC"
);
$perdidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $conexion->query(
    "SELECT * FROM reportes
     WHERE tipo_reporte = 'Encontrado'
       AND estado_historial = 'activo'
     ORDER BY id DESC"
);
$encontrados = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $conexion->query(
    "SELECT * FROM reportes
     WHERE estado_historial = 'archivado'
     ORDER BY id DESC"
);
$historial = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* ==========================================
   CONSULTAR USUARIOS REGISTRADOS Y SUS ROLES
   ========================================== */

$stmtUsuarios = $conexion->query(
    "SELECT id, nombre, correo, rol, grado,
            tipo_id, num_id, tipo_documento, numero_documento
     FROM usuarios
     ORDER BY nombre ASC"
);
$usuarios = $stmtUsuarios->fetchAll(PDO::FETCH_ASSOC);

/* ==========================================
   CONSULTAR RECLAMACIONES
   ========================================== */

$stmt = $conexion->query(
    "SELECT sr.*,
            r.nombre_objeto, r.tipo_reporte, r.descripcion, r.imagen
     FROM solicitudes_reclamo sr
     LEFT JOIN reportes r ON r.id = sr.id_reporte
     ORDER BY
         CASE WHEN sr.estado = 'Pendiente' THEN 0 ELSE 1 END,
         sr.id DESC"
);
$reclamaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

$stmt = $conexion->query(
    "SELECT COUNT(*) FROM solicitudes_reclamo
     WHERE estado = 'Pendiente'"
);
$totalReclamacionesPendientes = (int)$stmt->fetchColumn();

/* ==========================================
   MOSTRAR ESTADO DE COINCIDENCIA
   ========================================== */

function mostrarEstado($estado): void
{
    $estados = [
        'rojo' => '🔴 Sin coincidencia',
        'amarillo' => '🟡 En espera',
        'naranja' => '🟠 ¡Coincidencia!'
    ];

    if (!isset($estados[$estado])) {
        $estado = 'rojo';
    }

    echo '<div class="estado-actual estado-' . e($estado) . '">' .
         $estados[$estado] . '</div>';
}

/* ==========================================
   MOSTRAR IMAGEN
   ========================================== */

function mostrarImagen(array $objeto): void
{
    $ruta = obtenerRutaImagen($objeto);

    if ($ruta !== '') {
        ?>
        <img
            class="imagen-reporte"
            src="<?= e($ruta) ?>"
            alt="Fotografía del objeto"
            loading="lazy"
            onerror="this.style.display='none';this.nextElementSibling.style.display='flex';"
        >
        <div class="sin-imagen" style="display:none">Imagen no disponible</div>
        <?php
    } else {
        echo '<div class="sin-imagen">Sin fotografía registrada</div>';
    }
}

/* ==========================================
   MOSTRAR TARJETAS DE REPORTES
   El formulario usa usuarios registrados.
   Funciona igual para perdidos y encontrados.
   ========================================== */

function mostrarTarjetas(array $reportes, array $usuarios): void
{
    if (!$reportes) {
        echo '<div class="sin-reportes">No hay reportes activos en esta sección.</div>';
        return;
    }

    foreach ($reportes as $objeto) {
        $id = (int)($objeto['id'] ?? 0);
        $estado = $objeto['estado_coincidencia'] ?? 'rojo';

        if (!in_array($estado, ['rojo', 'amarillo', 'naranja'], true)) {
            $estado = 'rojo';
        }
        ?>

        <div class="tarjeta">
            <div class="contenido-tarjeta">
                <h3 class="nombre-objeto">
                    <?= e($objeto['nombre_objeto'] ?? 'Objeto sin nombre') ?>
                </h3>

                <p>
                    <strong>Reportado por:</strong>
                    <?= e($objeto['nombre_reportante'] ?? 'No registrado') ?>
                    <?php if (!empty($objeto['curso'])): ?>
                        (<?= e($objeto['curso']) ?>)
                    <?php endif; ?>
                </p>

                <p><strong>Lugar:</strong>
                    <?= e($objeto['lugar'] ?? 'No especificado') ?>
                </p>

                <p><strong>Descripción:</strong>
                    <?= e($objeto['descripcion'] ?? 'Sin descripción') ?>
                </p>

                <?php mostrarEstado($estado); ?>

                <div class="botones-estado">
                    <?php
                    $botones = [
                        'rojo' => ['🔴 Sin coincidencia', 'btn-rojo'],
                        'amarillo' => ['🟡 En espera', 'btn-amarillo'],
                        'naranja' => ['🟠 ¡Coincidencia!', 'btn-naranja']
                    ];

                    foreach ($botones as $valor => $datos):
                    ?>
                        <form method="POST">
                            <input type="hidden" name="id_reporte" value="<?= $id ?>">
                            <input type="hidden" name="nuevo_estado" value="<?= e($valor) ?>">
                            <button
                                type="submit"
                                name="cambiar_estado"
                                value="1"
                                class="btn-estado <?= e($datos[1]) ?>"
                            ><?= e($datos[0]) ?></button>
                        </form>
                    <?php endforeach; ?>
                </div>

                <?php if ($estado === 'naranja'): ?>
                    <details class="formulario-entrega" open>
                        <summary>🟢 Registrar entrega del objeto</summary>

                        <form method="POST" class="campos-entrega">
                            <input type="hidden" name="id_reporte" value="<?= $id ?>">

                            <label for="usuario_recibe_<?= $id ?>">
                                Selecciona el estudiante que recibirá el objeto
                            </label>

                            <select
                                id="usuario_recibe_<?= $id ?>"
                                name="usuario_recibe"
                                class="selector-usuario"
                                required
                                onchange="mostrarDatosUsuario(this, 'datos_usuario_<?= $id ?>')"
                            >
                                <option value="">Selecciona un usuario registrado</option>

                                <?php foreach ($usuarios as $usuario): ?>
                                    <option
                                        value="<?= (int)$usuario['id'] ?>"
                                        data-nombre="<?= e($usuario['nombre'] ?? '') ?>"
                                        data-curso="<?= e($usuario['grado'] ?? '') ?>"
                                        data-rol="<?= e($usuario['rol'] ?? '') ?>"
                                        data-tipo="<?= e(
                                            !empty($usuario['tipo_documento'])
                                                ? $usuario['tipo_documento']
                                                : ($usuario['tipo_id'] ?? '')
                                        ) ?>"
                                        data-documento="<?= e(
                                            !empty($usuario['numero_documento'])
                                                ? $usuario['numero_documento']
                                                : ($usuario['num_id'] ?? '')
                                        ) ?>"
                                    >
                                        <?= e($usuario['nombre'] ?? 'Sin nombre') ?>
                                        | <?= e($usuario['rol'] ?? 'Sin rol') ?>
                                        <?php if (!empty($usuario['grado'])): ?>
                                            | Curso <?= e($usuario['grado']) ?>
                                        <?php endif; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>

                            <div id="datos_usuario_<?= $id ?>" class="datos-usuario">
                                <p><strong>Nombre:</strong> <span data-campo="nombre">Selecciona un usuario</span></p>
                                <p><strong>Curso:</strong> <span data-campo="curso">No seleccionado</span></p>
                                <p><strong>Rol:</strong> <span data-campo="rol">No seleccionado</span></p>
                                <p><strong>Documento:</strong> <span data-campo="documento">No seleccionado</span></p>
                            </div>

                            <p class="nota">
                                Los datos se toman de la cuenta registrada.
                                El usuario receptor no tiene que ser quien reportó el objeto encontrado.
                            </p>

                            <button
                                type="submit"
                                name="marcar_entregado"
                                value="1"
                                class="btn-verde"
                                onclick="return confirm('¿Confirmas que entregaste el objeto al usuario seleccionado?');"
                            >Confirmar entrega</button>
                        </form>
                    </details>
                <?php endif; ?>
            </div>

            <div class="contenedor-imagen">
                <?php mostrarImagen($objeto); ?>
            </div>
        </div>

        <?php
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Panel de Administrador</title>

<style>
*{box-sizing:border-box}
body{margin:0;font-family:Arial,sans-serif;background:#f7eedf;color:#26364a}
.barra-superior{min-height:90px;background:#fff;border-bottom:5px solid #8cc8e8;display:flex;justify-content:center;align-items:center;gap:15px;padding:12px;flex-wrap:wrap}
.btn-historial-superior,.btn-cerrar,.btn-campana{padding:13px 22px;border-radius:30px;font-weight:bold;font-size:15px}
.btn-historial-superior{background:#444;color:#fff;border:0;cursor:pointer}
.btn-cerrar{background:#f69b95;color:#fff;text-decoration:none}
.btn-campana{background:#e0f2fe;color:#0879d7;border:2px solid #8cc8e8;text-decoration:none}
.contador-reclamos{background:#ef5350;color:white;border-radius:50px;padding:4px 8px}
.contenedor{max-width:1400px;margin:auto;padding:45px 30px 80px}
.cabecera{display:flex;justify-content:space-between;align-items:center;gap:20px;margin-bottom:35px}
.titulo{font-size:30px;margin:0}
.subtitulo{font-size:17px}
.btn-actualizar{background:#78bee5;color:white;padding:13px 20px;border:0;border-radius:10px;font-weight:bold;cursor:pointer}
.columnas{display:grid;grid-template-columns:1fr 1fr;gap:25px;align-items:start}
.columna h2{font-size:23px;padding-bottom:8px}
.titulo-perdidos{color:#e95350;border-bottom:2px solid #ef807b}
.titulo-encontrados{color:#0879d7;border-bottom:2px solid #71b9ed}
.tarjeta{background:white;border-radius:0 16px 16px 0;border-left:7px solid #35ad72;padding:22px;margin-bottom:20px;box-shadow:0 5px 13px #00000010;display:grid;grid-template-columns:minmax(0,1fr) 180px;gap:18px}
.contenido-tarjeta{min-width:0}
.nombre-objeto{color:#2868a8;font-size:21px;margin-top:0}
.dato{font-size:16px;margin:8px 0;overflow-wrap:anywhere}
.contenedor-imagen{width:180px;height:170px;display:flex;justify-content:center;align-items:center;overflow:hidden}
.imagen-reporte{width:100%;height:100%;object-fit:contain}
.sin-imagen{width:100%;height:100%;min-height:90px;display:flex;align-items:center;justify-content:center;text-align:center;color:#777;border:1px dashed #ddd;padding:10px}
.botones-estado{display:flex;flex-wrap:wrap;gap:8px;margin-top:16px}
.btn-estado{border:0;padding:9px 13px;border-radius:22px;font-weight:bold;cursor:pointer;color:white}
.btn-rojo{background:#ef5350}
.btn-amarillo{background:#f6c945;color:#333}
.btn-naranja{background:#ff922b}
.estado-actual{display:inline-block;padding:8px 15px;border-radius:20px;font-weight:bold;margin-top:10px}
.estado-rojo{background:#ffd2d2;color:#a60000}
.estado-amarillo{background:#fff0a8;color:#725b00}
.estado-naranja{background:#ffd0a3;color:#914600}
.formulario-entrega{margin-top:16px;padding:14px;background:#f0f9ff;border:1px solid #b8def5;border-radius:12px}
.formulario-entrega summary{color:#0879d7;font-weight:bold;cursor:pointer}
.campos-entrega{display:flex;flex-direction:column;gap:9px;margin-top:15px}
.campos-entrega label{font-size:14px;font-weight:bold}
.campos-entrega input,.campos-entrega select{width:100%;padding:10px;border:1px solid #b8c9d8;border-radius:8px;background:white;font-size:15px}
.datos-usuario{background:#fff;padding:10px 12px;border-radius:8px;border:1px solid #d5e6f3;overflow-wrap:anywhere}
.datos-usuario p{margin:6px 0}
.nota{font-size:13px;color:#526577}
.btn-verde{background:#35b875;color:white;border:0;padding:12px;border-radius:22px;font-weight:bold;cursor:pointer;margin-top:8px}
.sin-reportes{background:#fff;padding:22px;border-radius:12px;color:#777}
#historial,#usuarios-registrados,#reclamaciones{margin-top:45px;background:white;padding:25px;border-radius:18px;box-shadow:0 5px 20px #00000010;overflow-x:auto}
#historial{display:none}
#historial h2,#usuarios-registrados h2,#reclamaciones h2{color:#0879d7}
.tabla{width:100%;border-collapse:collapse;margin-top:18px}
.tabla th{background:#e0f2fe;color:#075985;padding:12px;text-align:left}
.tabla td{padding:12px;border-bottom:1px solid #e5e7eb;vertical-align:top}
.foto-tabla{width:90px;height:75px;object-fit:contain}
.estado-pendiente,.estado-atendida{display:inline-block;padding:6px 10px;border-radius:15px;font-weight:bold}
.estado-pendiente{background:#fff0a8;color:#725b00}
.estado-atendida{background:#d8f5e5;color:#167346}
.btn-atender{background:#0879d7;color:white;border:0;padding:9px 13px;border-radius:18px;font-weight:bold;cursor:pointer}
.mensaje-admin{margin-bottom:25px;padding:15px 20px;border-radius:12px;background:#e0f2fe;border:1px solid #8cc8e8;color:#075985;font-weight:bold}
@media(max-width:1000px){.columnas{grid-template-columns:1fr}}
@media(max-width:600px){.contenedor{padding:25px 12px}.cabecera{flex-direction:column;align-items:flex-start}.titulo{font-size:25px}.tarjeta{grid-template-columns:1fr}.contenedor-imagen{width:100%;max-width:280px;height:190px}}
</style>
</head>

<body>
<div class="barra-superior">
    <button type="button" class="btn-historial-superior" onclick="mostrarHistorial()">🗄️ Historial</button>
    <a href="#usuarios-registrados" class="btn-campana">👥 Usuarios y roles</a>
    <a href="#reclamaciones" class="btn-campana">
        🔔 Reclamaciones
        <span class="contador-reclamos"><?= $totalReclamacionesPendientes ?></span>
    </a>
    <a href="logica/logout.php" class="btn-cerrar">Cerrar Sesión Admin</a>
</div>

<div class="contenedor">

<?php if ($mensajeAdmin !== ''): ?>
    <div class="mensaje-admin"><?= e($mensajeAdmin) ?></div>
<?php endif; ?>

<div class="cabecera">
    <div>
        <h1 class="titulo">Detección de Coincidencias e Información Completa</h1>
        <p class="subtitulo">Consulta los reportes y registra las entregas a usuarios registrados.</p>
    </div>
    <button type="button" class="btn-actualizar" onclick="location.reload()">🔄 Actualizar Lista</button>
</div>

<div class="columnas">
    <div class="columna">
        <h2 class="titulo-perdidos">Objetos Reportados como Perdidos</h2>
        <?php mostrarTarjetas($perdidos, $usuarios); ?>
    </div>

    <div class="columna">
        <h2 class="titulo-encontrados">Objetos Reportados como Encontrados</h2>
        <?php mostrarTarjetas($encontrados, $usuarios); ?>
    </div>
</div>

<!-- HISTORIAL -->
<section id="historial">
    <h2>🗄️ Historial de Objetos Entregados</h2>
    <p>Aquí aparecen los objetos entregados y archivados.</p>

    <?php if ($historial): ?>
    <table class="tabla">
        <thead>
        <tr>
            <th>Objeto</th><th>Reportado por</th><th>Estudiante que recibió</th>
            <th>Curso</th><th>Documento</th><th>Fecha y hora</th>
            <th>Descripción</th><th>Fotografía</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($historial as $objeto): ?>
        <tr>
            <td><?= e($objeto['nombre_objeto'] ?? 'Sin nombre') ?></td>
            <td><?= e($objeto['nombre_reportante'] ?? 'No disponible') ?></td>
            <td><?= e($objeto['nombre_recibio'] ?? 'Sin datos anteriores') ?></td>
            <td><?= e($objeto['curso_recibio'] ?? 'Sin datos') ?></td>
            <td>
                <?= e($objeto['tipo_documento_recibio'] ?? '') ?><br>
                <?= e($objeto['numero_documento_recibio'] ?? 'Sin documento') ?>
            </td>
            <td>
                <?php if (!empty($objeto['fecha_entrega'])): ?>
                    <?= e(date('d/m/Y H:i:s', strtotime($objeto['fecha_entrega']))) ?>
                <?php else: ?>
                    Sin fecha registrada
                <?php endif; ?>
            </td>
            <td><?= e($objeto['descripcion'] ?? 'Sin descripción') ?></td>
            <td>
                <?php $foto = obtenerRutaImagen($objeto); ?>
                <?php if ($foto !== ''): ?>
                    <img class="foto-tabla" src="<?= e($foto) ?>" alt="Objeto entregado">
                <?php else: ?>Sin fotografía<?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No hay objetos archivados.</p>
    <?php endif; ?>
</section>

<!-- USUARIOS Y ROLES -->
<section id="usuarios-registrados">
    <h2>👥 Usuarios registrados y sus roles</h2>
    <p>Estos son los usuarios disponibles para seleccionar como receptores de objetos.</p>

    <?php if ($usuarios): ?>
    <table class="tabla">
        <thead>
        <tr>
            <th>Nombre</th><th>Correo</th><th>Rol</th><th>Curso</th><th>Documento</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($usuarios as $usuario): ?>
        <tr>
            <td><?= e($usuario['nombre'] ?? '') ?></td>
            <td><?= e($usuario['correo'] ?? '') ?></td>
            <td><?= e($usuario['rol'] ?? 'Sin rol') ?></td>
            <td><?= e($usuario['grado'] ?? 'No registrado') ?></td>
            <td>
                <?= e($usuario['tipo_documento'] ?: ($usuario['tipo_id'] ?? '')) ?><br>
                <?= e($usuario['numero_documento'] ?: ($usuario['num_id'] ?? 'No registrado')) ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No hay usuarios registrados.</p>
    <?php endif; ?>
</section>

<!-- RECLAMACIONES -->
<section id="reclamaciones">
    <h2>🔔 Solicitudes de reclamación</h2>
    <p>Consulta los datos del estudiante que reclama y el estado de la solicitud.</p>

    <?php if ($reclamaciones): ?>
    <table class="tabla">
        <thead>
        <tr>
            <th>Objeto</th><th>Persona que reclama</th><th>Fecha del reclamo</th>
            <th>Estado</th><th>Estudiante que recibió</th><th>Curso</th>
            <th>Documento</th><th>Fecha y hora de entrega</th><th>Fotografía</th><th>Acción</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($reclamaciones as $solicitud): ?>
        <?php
            $estadoReclamo = $solicitud['estado'] ?? 'Pendiente';
            $nombreReclamante = $solicitud['nombre_reclamante']
                ?: ($solicitud['nombre_usuario'] ?? 'Sin nombre');
            $fotoReclamo = obtenerRutaImagen($solicitud);
        ?>
        <tr>
            <td>
                <strong><?= e($solicitud['nombre_objeto'] ?? 'Objeto no disponible') ?></strong><br>
                Reporte #<?= (int)$solicitud['id_reporte'] ?>
            </td>
            <td><?= e($nombreReclamante) ?></td>
            <td><?= e($solicitud['fecha_solicitud'] ?? 'Sin fecha') ?></td>
            <td>
                <span class="<?= $estadoReclamo === 'Pendiente' ? 'estado-pendiente' : 'estado-atendida' ?>">
                    <?= e($estadoReclamo) ?>
                </span>
            </td>
            <td>
                <?= e($solicitud['estudiante_recibio'] ?: (
                    $estadoReclamo === 'Atendida' ? $nombreReclamante : 'Pendiente de entrega'
                )) ?>
            </td>
            <td><?= e($solicitud['curso_reclamante'] ?? 'Sin curso') ?></td>
            <td>
                <?= e($solicitud['tipo_documento'] ?? '') ?><br>
                <?= e($solicitud['numero_documento'] ?? 'Sin documento') ?>
            </td>
            <td>
                <?= !empty($solicitud['fecha_entrega'])
                    ? e(date('d/m/Y H:i:s', strtotime($solicitud['fecha_entrega'])))
                    : 'Pendiente de entrega' ?>
            </td>
            <td>
                <?php if ($fotoReclamo !== ''): ?>
                    <img class="foto-tabla" src="<?= e($fotoReclamo) ?>" alt="Objeto reclamado">
                <?php else: ?>Sin fotografía<?php endif; ?>
            </td>
            <td>
                <?php if ($estadoReclamo === 'Pendiente'): ?>
                    <form method="POST" onsubmit="return confirm('¿Confirmas que se entregó el objeto de esta reclamación?');">
                        <input type="hidden" name="id_solicitud" value="<?= (int)$solicitud['id'] ?>">
                        <button class="btn-atender" type="submit" name="marcar_reclamo_atendido" value="1">
                            ✓ Confirmar entrega
                        </button>
                    </form>
                <?php else: ?>
                    ✓ Atendida
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No hay solicitudes de reclamación registradas.</p>
    <?php endif; ?>
</section>

</div>

<script>
function mostrarHistorial() {
    const historial = document.getElementById('historial');

    if (historial.style.display === 'block') {
        historial.style.display = 'none';
    } else {
        historial.style.display = 'block';
        historial.scrollIntoView({behavior: 'smooth', block: 'start'});
    }
}

function mostrarDatosUsuario(select, idContenedor) {
    const contenedor = document.getElementById(idContenedor);
    const opcion = select.options[select.selectedIndex];

    const nombre = opcion.dataset.nombre || 'No registrado';
    const curso = opcion.dataset.curso || 'No registrado';
    const rol = opcion.dataset.rol || 'Sin rol';
    const tipo = opcion.dataset.tipo || '';
    const documento = opcion.dataset.documento || 'No registrado';

    contenedor.querySelector('[data-campo="nombre"]').textContent = nombre;
    contenedor.querySelector('[data-campo="curso"]').textContent = curso;
    contenedor.querySelector('[data-campo="rol"]').textContent = rol;
    contenedor.querySelector('[data-campo="documento"]').textContent =
        (tipo ? tipo + ' ' : '') + documento;
}
</script>

</body>
</html>


