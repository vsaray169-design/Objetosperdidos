-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS `objetosperdidos` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

-- Seleccionar la base de datos
USE `objetosperdidos`;

-- Crear tabla grado
CREATE TABLE IF NOT EXISTS `grado` (
  `GradoId` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`GradoId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `grado` (`GradoId`, `Nombre`) VALUES
(1, 'Sexto'), (2, 'Séptimo'), (3, 'Octavo'),
(4, 'Noveno'), (5, 'Décimo'), (6, 'Once');

-- Crear tabla curso
CREATE TABLE IF NOT EXISTS `curso` (
  `CursoId` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `GradoId` int(11) NOT NULL,
  PRIMARY KEY (`CursoId`),
  KEY `GradoId` (`GradoId`),
  CONSTRAINT `curso_ibfk_1` FOREIGN KEY (`GradoId`) REFERENCES `grado` (`GradoId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `curso` (`CursoId`, `Nombre`, `GradoId`) VALUES
(1, 'Grado 601', 1), (2, 'Grado 701', 2), (3, 'Grado 801', 3),
(4, 'Grado 901', 4), (5, 'Grado 1001', 5), (6, 'Grado 1101', 6);

-- Crear tabla rol
CREATE TABLE IF NOT EXISTS `rol` (
  `RolId` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`RolId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `rol` (`RolId`, `Nombre`) VALUES
(1, 'Estudiante'), (2, 'Profesor'), (3, 'Administrador');

-- Crear tabla tipodocumento
CREATE TABLE IF NOT EXISTS `tipodocumento` (
  `TipoDocumentoId` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`TipoDocumentoId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `tipodocumento` (`TipoDocumentoId`, `Nombre`) VALUES
(1, 'Tarjeta de Identidad'), (2, 'Cédula de Ciudadanía');

-- Crear tabla estado
CREATE TABLE IF NOT EXISTS `estado` (
  `EstadoId` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  PRIMARY KEY (`EstadoId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `estado` (`EstadoId`, `Nombre`) VALUES
(1, 'Perdido'), (2, 'Encontrado/Entregado');

-- Crear tabla usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `UsuarioId` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `TipoDocumentoId` int(11) NOT NULL,
  `Edad` int(11) NOT NULL,
  `CursoId` int(11) NOT NULL,
  `Genero` char(1) NOT NULL,
  `Telefono` varchar(50) NOT NULL,
  `RolId` int(11) NOT NULL,
  PRIMARY KEY (`UsuarioId`),
  KEY `CursoId` (`CursoId`),
  KEY `RolId` (`RolId`),
  KEY `TipoDocumentoId` (`TipoDocumentoId`),
  CONSTRAINT `usuario_ibfk_1` FOREIGN KEY (`CursoId`) REFERENCES `curso` (`CursoId`),
  CONSTRAINT `usuario_ibfk_2` FOREIGN KEY (`RolId`) REFERENCES `rol` (`RolId`),
  CONSTRAINT `usuario_ibfk_3` FOREIGN KEY (`TipoDocumentoId`) REFERENCES `tipodocumento` (`TipoDocumentoId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Crear tabla objetosperdidos
CREATE TABLE IF NOT EXISTS `objetosperdidos` (
  `ObjetoId` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(50) NOT NULL,
  `Descripcion` varchar(255) NOT NULL,
  `FechaPerdida` date NOT NULL,
  `LugarPerdida` varchar(100) NOT NULL,
  `EstadoId` int(11) NOT NULL,
  `CursoId` int(11) NOT NULL,
  PRIMARY KEY (`ObjetoId`),
  KEY `EstadoId` (`EstadoId`),
  CONSTRAINT `objetosperdidos_ibfk_1` FOREIGN KEY (`EstadoId`) REFERENCES `estado` (`EstadoId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Crear tabla entregas
CREATE TABLE IF NOT EXISTS `entregas` (
  `EntregasId` int(11) NOT NULL AUTO_INCREMENT,
  `ObjetoId` int(11) NOT NULL,
  `UsuarioId` int(11) NOT NULL,
  `FechaEntrega` date NOT NULL,
  `Recibido` int(11) NOT NULL,
  PRIMARY KEY (`EntregasId`),
  KEY `ObjetoId` (`ObjetoId`),
  KEY `UsuarioId` (`UsuarioId`),
  CONSTRAINT `entregas_ibfk_2` FOREIGN KEY (`UsuarioId`) REFERENCES `usuario` (`UsuarioId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

ALTER TABLE `usuario` 
ADD COLUMN `Correo` VARCHAR(100) NOT NULL UNIQUE AFTER `Telefono`,
ADD COLUMN `Contrasena` VARCHAR(255) NOT NULL AFTER `Correo`;