<?php
// includes/footer.php
?>
  </main>
  
  <!-- Botón de acceso exclusivo para Admin -->
  <a href="login_admin.php" class="btn-admin-flotante">
    ⚙️ Admin
  </a>

  <!-- Enlace a la carpeta JS con mayúsculas -->
  <script src="JS/main.js"></script>
</body>
</html>