<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Objetos Perdidos</title>
    <link rel="stylesheet" href="CCS/style.css">
</head>
<body>
    <header>
        <h1>Colegio Técnico Palermo</h1>
        <p>Sede Chapinero - Sistema de Control y Recuperación de Objetos Perdidos</p>
        <nav>
            <a href="index.php">Inicio</a>
            
            <?php if (isset($_SESSION['usuario_id'])): ?>
                <a href="reportar_perdido.php">Reportar Perdido</a>
                <a href="reportar_encontrado.php">Reportar Encontrado</a>
                
                <?php if (isset($_SESSION['usuario_rol']) && ((int)$_SESSION['usuario_rol'] === 3 || $_SESSION['usuario_rol'] === 'admin')): ?>
                    <a href="panel_admin.php">Panel Admin</a>
                <?php endif; ?>
                
                <a href="logout.php">Cerrar Sesión (<?php echo htmlspecialchars($_SESSION['usuario_nombre']); ?>)</a>
            <?php else: ?>
                <a href="registro.php">Registrarse</a>
                <a href="login.php">Iniciar Sesión</a>
            <?php endif; ?>
        </nav>
    </header>
    <hr>