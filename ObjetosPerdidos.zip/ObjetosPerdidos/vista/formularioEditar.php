<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';
require_once __DIR__ . '/../config/conexionBDD.php';
require_once __DIR__ . '/../datos/estudianteDAO.php';

iniciarSesionSegura();

if (!isset($_SESSION['usuario'])) {
    header('Location: ../index.php');
    exit();
}

$id = $_GET['id'] ?? null;
$objeto = $id ? obtenerObjetoPorIdDAO($conexion, $id) : null;

if (!$objeto) {
    header('Location: listaEstudiante.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Reporte</title>
    <style>
        body { font-family: Arial, sans-serif; background-color: #F3E9D7; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .card { background: white; padding: 25px; border-radius: 10px; width: 100%; max-width: 400px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .grupo { margin-bottom: 12px; }
        label { display: block; font-weight: bold; margin-bottom: 4px; }
        input, textarea { width: 100%; padding: 8px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        .btn-sub { width: 100%; padding: 10px; background-color: #83c0df; color: white; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; margin-top: 10px; }
        .btn-cancel { display: block; text-align: center; margin-top: 10px; color: #666; text-decoration: none; }
    </style>
</head>
<body>

<div class="card">
    <h3>Editar Reporte (<?php echo htmlspecialchars($objeto['tipo_reporte']); ?>)</h3>
    <form action="../procesos/actualizarEstudiante.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $objeto['id']; ?>">

        <div class="grupo">
            <label>Nombre del Objeto:</label>
            <input type="text" name="nombre_objeto" value="<?php echo htmlspecialchars($objeto['nombre_objeto']); ?>" required>
        </div>
        <div class="grupo">
            <label>Lugar:</label>
            <input type="text" name="lugar" value="<?php echo htmlspecialchars($objeto['lugar']); ?>" required>
        </div>
        <div class="grupo">
            <label>Fecha:</label>
            <input type="date" name="fecha_suceso" value="<?php echo htmlspecialchars($objeto['fecha_suceso']); ?>" required>
        </div>
        <div class="grupo">
            <label>Descripción:</label>
            <textarea name="descripcion" rows="3"><?php echo htmlspecialchars($objeto['descripcion']); ?></textarea>
        </div>

        <button type="submit" class="btn-sub">Guardar Cambios</button>
        <a href="listaEstudiante.php" class="btn-cancel">Cancelar</a>
    </form>
</div>

</body>
</html>