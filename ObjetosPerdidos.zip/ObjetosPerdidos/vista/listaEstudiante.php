
<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';
require_once __DIR__ . '/../config/conexionBDD.php';

iniciarSesionSegura();

if (!isset($_SESSION['usuario'])) {
    header('Location: ../index.php');
    exit();
}

$usuario = $_SESSION['usuario'];

$nombreUsuario = is_array($usuario)
    ? ($usuario['nombre'] ?? 'Usuario')
    : $usuario;

$nombreFormulario = is_array($usuario)
    ? ($usuario['nombre'] ?? '')
    : (string) $usuario;

$rolUsuario = is_array($usuario)
    ? ($usuario['rol'] ?? '')
    : '';

$edadUsuario = is_array($usuario)
    ? ($usuario['edad'] ?? '')
    : '';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reportes Palermo - Colegio Técnico Palermo</title>

    <style>
        :root {
            --azul: #72B4EB;
            --beige: #F3E9D7;
            --rosa: #FF9AA2;
            --verde: #CBE8DA;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: var(--beige);
            margin: 0;
            padding: 30px 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
            position: relative;
            overflow-x: hidden;
        }

        .fondo-animado {
            position: fixed;
            inset: 0;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }

        .objeto-escolar {
            position: absolute;
            bottom: -80px;
            font-size: 2.2rem;
            opacity: .5;
            animation: flotar 12s infinite linear;
        }

        .obj1 { left: 8%; animation-duration: 10s; }
        .obj2 { left: 22%; animation-delay: 3s; animation-duration: 12s; }
        .obj3 { left: 40%; animation-delay: 1s; animation-duration: 9s; }
        .obj4 { left: 58%; animation-delay: 5s; animation-duration: 11s; }
        .obj5 { left: 75%; animation-delay: 2s; animation-duration: 13s; }
        .obj6 { left: 88%; animation-delay: 4s; animation-duration: 10s; }

        @keyframes flotar {
            0% {
                transform: translateY(0) rotate(0deg);
                opacity: 0;
            }
            20%, 80% {
                opacity: .5;
            }
            100% {
                transform: translateY(-110vh) rotate(360deg);
                opacity: 0;
            }
        }

        .top-acciones {
            width: 100%;
            max-width: 1000px;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 25px;
            position: relative;
            z-index: 10;
        }

        .btn-accion {
            flex: 1;
            min-width: 200px;
            padding: 16px 20px;
            border: none;
            border-radius: 14px;
            font-weight: bold;
            cursor: pointer;
            color: white;
            text-align: center;
            font-size: 1rem;
            box-shadow: 0 4px 12px rgba(0,0,0,.08);
            transition: all .2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
        }

        .btn-accion:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0,0,0,.12);
        }

        .btn-perdido { background-color: var(--rosa); }
        .btn-encontrado { background-color: var(--azul); }
        .btn-imagenes { background-color: #8E7CC3; }

        .box-formulario-wrapper {
            width: 100%;
            max-width: 900px;
            position: relative;
            z-index: 10;
        }

        .form-box {
            display: none;
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0,0,0,.08);
            margin-bottom: 25px;
        }

        .form-box.active {
            display: block;
        }

        .formulario-con-foto {
            display: grid;
            grid-template-columns: minmax(0, 1fr) minmax(220px, .8fr);
            gap: 24px;
            align-items: start;
        }

        .columna-datos {
            min-width: 0;
        }

        .grupo {
            margin-bottom: 12px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            font-size: .9rem;
            color: #444;
        }

        input, select, textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: .9rem;
            font-family: inherit;
        }

        textarea {
            resize: vertical;
        }

        .panel-fotografia {
            background: #FAF8F5;
            border: 2px dashed var(--azul);
            border-radius: 14px;
            padding: 18px;
            text-align: center;
            position: sticky;
            top: 15px;
        }

        .panel-fotografia .icono-foto {
            font-size: 2.8rem;
            margin-bottom: 10px;
        }

        .panel-fotografia p {
            color: #666;
            font-size: .9rem;
            line-height: 1.5;
        }

        .vista-previa {
            width: 100%;
            height: 220px;
            max-height: 220px;
            object-fit: contain;
            border-radius: 10px;
            display: none;
            margin-top: 12px;
            background: white;
        }

        .btn-guardar {
            background-color: #27ae60;
            color: white;
            border: none;
            padding: 12px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 10px;
            width: 100%;
        }

        .alerta-ok {
            background: var(--verde);
            color: #2c3e50;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 15px;
            text-align: center;
            font-weight: bold;
        }

        .card-usuario-grande {
            width: 100%;
            max-width: 650px;
            background: white;
            padding: 30px 35px;
            border-radius: 20px;
            box-shadow: 0 6px 20px rgba(0,0,0,.08);
            position: relative;
            z-index: 10;
            margin-top: 10px;
        }

        .header-panel {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            gap: 15px;
            border-bottom: 2px dashed #f0e6d8;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }

        .saludo-titulo {
            font-size: 1.6rem;
            color: #222;
            margin: 0 0 5px;
            font-weight: bold;
        }

        .saludo-subtitulo {
            color: #888;
            font-size: .9rem;
            display: inline-block;
        }

        .mensaje-confianza {
            font-size: .98rem;
            line-height: 1.6;
            color: #555;
            margin-top: 15px;
            background: #FAF8F5;
            padding: 15px 20px;
            border-radius: 12px;
            border-left: 4px solid var(--rosa);
        }

        .btn-logout {
            background-color: var(--rosa);
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 20px;
            font-weight: bold;
            font-size: .9rem;
            white-space: nowrap;
        }

        .footer-seccion {
            margin-top: 100px;
            width: 100%;
            max-width: 800px;
            text-align: left;
            position: relative;
            z-index: 10;
            padding-bottom: 40px;
        }

        .titulo-palermo {
            font-family: Georgia, 'Times New Roman', serif;
            font-size: 3.2rem;
            font-weight: bold;
            color: #112233;
            margin: 0 0 30px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .corazon-icon {
            font-size: 2.4rem;
        }

        .mensaje-institucional {
            font-size: 1.05rem;
            line-height: 1.7;
            color: #333;
            margin-bottom: 30px;
        }

        /* Galería */
        .galeria-wrapper {
            display: none;
            width: 100%;
            max-width: 1000px;
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 4px 15px rgba(0,0,0,.08);
            position: relative;
            z-index: 10;
            margin-bottom: 25px;
        }

        .galeria-wrapper.active {
            display: block;
        }

        .titulo-galeria {
            color: #333;
            text-align: center;
            margin-top: 0;
        }

        .texto-galeria {
            text-align: center;
            color: #666;
            line-height: 1.5;
        }

        .galeria {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }

        .tarjeta-objeto {
            background: #fffdf9;
            border: 1px solid #f0e6d8;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,.06);
            min-width: 0;
        }

        .tarjeta-objeto img {
            width: 100%;
            height: 210px;
            object-fit: contain;
            object-position: center;
            display: block;
            background-color: #FAF8F5;
            padding: 5px;
        }

        .sin-fotografia {
            height: 160px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 15px;
            background: #FAF8F5;
            color: #777;
            text-align: center;
        }

        .contenido-objeto {
            padding: 16px;
        }

        .contenido-objeto h3 {
            margin: 0 0 10px;
            color: #333;
            overflow-wrap: anywhere;
        }

        .tipo-objeto {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 15px;
            font-size: .78rem;
            font-weight: bold;
            margin-bottom: 10px;
        }

        .tipo-encontrado {
            background: #dcecff;
            color: #245b78;
        }

        .contenido-objeto p {
            font-size: .9rem;
            line-height: 1.5;
            overflow-wrap: anywhere;
        }

        .btn-reclamar {
            width: 100%;
            padding: 11px;
            margin-top: 8px;
            background: var(--rosa);
            color: white;
            border: none;
            border-radius: 9px;
            font-weight: bold;
            cursor: pointer;
        }

        .btn-reclamar:hover {
            background: #f17f8a;
        }

        .btn-cerrar-galeria {
            display: block;
            margin: 25px auto 0;
            padding: 11px 22px;
            border: none;
            border-radius: 10px;
            background: #eee;
            cursor: pointer;
            font-weight: bold;
        }

        .estado-galeria {
            text-align: center;
            padding: 20px;
            color: #666;
            grid-column: 1 / -1;
        }

        .fila-grado-curso {
            display: flex;
            gap: 15px;
        }

        .fila-grado-curso .grupo {
            flex: 1;
            min-width: 0;
        }

        /* Mapa interactivo */
        .panel-mapa {
            margin-top: 22px;
            padding: 18px;
            background: #f8fbff;
            border: 1px solid #dce8f5;
            border-radius: 14px;
        }

        .panel-mapa h3 {
            margin-top: 0;
            color: #263746;
        }

        .panel-mapa p {
            color: #626f7b;
            line-height: 1.5;
        }

        .mapa-colegio {
            position: relative;
            width: 100%;
            overflow: hidden;
            border: 2px solid #b9cddd;
            border-radius: 10px;
            background: white;
            cursor: crosshair;
            line-height: 0;
        }

        .mapa-colegio img {
            display: block;
            width: 100%;
            height: auto;
            pointer-events: none;
            user-select: none;
        }

        .punto-mapa {
            display: none;
            position: absolute;
            width: 20px;
            height: 20px;
            background: #e52323;
            border: 3px solid white;
            border-radius: 50%;
            box-shadow: 0 2px 8px rgba(0,0,0,.45);
            transform: translate(-50%, -50%);
            z-index: 2;
            pointer-events: none;
        }

        .punto-mapa.visible {
            display: block;
        }

        .texto-ubicacion-mapa {
            margin-top: 12px;
            padding: 10px;
            background: white;
            border-radius: 8px;
            font-size: .9rem;
            line-height: 1.5;
        }

        /* Modal de reclamación */
        .modal-reclamo {
            display: none;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, .58);
            z-index: 9999;
            justify-content: center;
            align-items: center;
            padding: 15px;
            overflow-y: auto;
        }

        .modal-reclamo.visible {
            display: flex;
        }

        .contenido-reclamo {
            background: white;
            width: 100%;
            max-width: 450px;
            max-height: 95vh;
            overflow-y: auto;
            padding: 25px;
            border-radius: 18px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, .2);
        }

        .contenido-reclamo h2 {
            margin-top: 0;
            color: #333;
            text-align: center;
        }

        .contenido-reclamo p {
            color: #666;
            line-height: 1.5;
        }

        .campo-reclamo {
            margin-bottom: 15px;
        }

        .campo-reclamo label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .campo-reclamo input,
        .campo-reclamo select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
        }

        .btn-enviar-reclamo,
        .btn-cancelar-reclamo {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 9px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 8px;
        }

        .btn-enviar-reclamo {
            background: var(--azul);
            color: white;
        }

        .btn-enviar-reclamo:disabled {
            opacity: .6;
            cursor: wait;
        }

        .btn-cancelar-reclamo {
            background: #eee;
            color: #333;
        }

        .mensaje-reclamo {
            display: none;
            padding: 10px;
            margin-bottom: 12px;
            border-radius: 8px;
            background: #fff0f0;
            color: #a22;
        }

        .mensaje-reclamo.visible {
            display: block;
        }

        @media (max-width: 650px) {
            body {
                padding: 20px 12px;
            }

            .formulario-con-foto {
                grid-template-columns: 1fr;
            }

            .panel-fotografia {
                position: static;
            }

            .fila-grado-curso {
                flex-direction: column;
                gap: 0;
            }

            .header-panel {
                flex-direction: column;
            }

            .titulo-palermo {
                font-size: 2.4rem;
            }

            .card-usuario-grande {
                padding: 24px 20px;
            }

            .top-acciones {
                flex-direction: column;
            }

            .btn-accion {
                width: 100%;
            }

            .galeria-wrapper {
                padding: 18px;
            }

            .galeria {
                grid-template-columns: 1fr;
            }

            .contenido-reclamo {
                padding: 20px;
            }
        }
    </style>
</head>

<body>

    <div class="fondo-animado" aria-hidden="true">
        <span class="objeto-escolar obj1">✏️</span>
        <span class="objeto-escolar obj2">📐</span>
        <span class="objeto-escolar obj3">🎒</span>
        <span class="objeto-escolar obj4">📚</span>
        <span class="objeto-escolar obj5">✂️</span>
        <span class="objeto-escolar obj6">🎨</span>
    </div>

    <div class="top-acciones">
        <button type="button" class="btn-accion btn-perdido"
            onclick="mostrarFormulario('Perdido')">
            📢 Reportar Objeto Perdido
        </button>

        <button type="button" class="btn-accion btn-encontrado"
            onclick="mostrarFormulario('Encontrado')">
            🔍 Reportar Objeto Encontrado
        </button>

        <button type="button" class="btn-accion btn-imagenes"
            onclick="mostrarImagenes()">
            🖼️ Imágenes
        </button>
    </div>

    <div class="box-formulario-wrapper">

        <?php if (isset($_GET['mensaje'])): ?>
            <div class="alerta-ok">
                <?php
                echo htmlspecialchars(
                    (string) $_GET['mensaje'],
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>
            </div>
        <?php endif; ?>

        <div id="boxFormulario" class="form-box">
            <h3 id="formTitulo" style="margin-top:0;color:#333;">
                Reportar Objeto
            </h3>

            <form id="formReporte"
                action="../procesos/guardarEstudiante.php"
                method="POST"
                enctype="multipart/form-data">

                <input type="hidden" name="tipo_reporte"
                    id="inputTipoReporte" value="">

                <div class="formulario-con-foto">
                    <div class="columna-datos">

                        <div class="grupo">
                            <label for="nombre_reportante">Nombre Completo:</label>
                            <input type="text" name="nombre_reportante"
                                id="nombre_reportante"
                                value="<?php echo htmlspecialchars(
                                    $nombreFormulario,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>" required>
                        </div>

                        <div class="grupo">
                            <label for="rolFormInput">Rol en la Institución:</label>
                            <select name="rol_institucional" id="rolFormInput"
                                onchange="verificarRolForm()" required>
                                <option value="Estudiante"
                                    <?php echo $rolUsuario === 'Estudiante' ? 'selected' : ''; ?>>
                                    Estudiante
                                </option>
                                <option value="Docente / Profesor(a)"
                                    <?php echo $rolUsuario === 'Docente' ? 'selected' : ''; ?>>
                                    Docente / Profesor(a)
                                </option>
                                <option value="Aseador(a)"
                                    <?php echo $rolUsuario === 'Aseadora' ? 'selected' : ''; ?>>
                                    Aseador(a)
                                </option>
                                <option value="Guardia"
                                    <?php echo $rolUsuario === 'Guardia' ? 'selected' : ''; ?>>
                                    Guardia
                                </option>
                                <option value="Otro Miembro">
                                    Otro Miembro de la Institución
                                </option>
                            </select>
                        </div>

                        <div class="fila-grado-curso" id="boxCursoForm">
                            <div class="grupo">
                                <label for="gradoFormInput">Grado:</label>
                                <select name="grado" id="gradoFormInput">
                                    <option value="">Seleccione</option>
                                    <option value="6">6°</option>
                                    <option value="7">7°</option>
                                    <option value="8">8°</option>
                                    <option value="9">9°</option>
                                    <option value="10">10°</option>
                                    <option value="11">11°</option>
                                </select>
                            </div>

                            <div class="grupo">
                                <label for="cursoFormInput">Curso:</label>
                                <select name="curso" id="cursoFormInput">
                                    <option value="">Seleccione</option>
                                    <option value="601">601</option>
                                    <option value="602">602</option>
                                    <option value="603">603</option>
                                    <option value="701">701</option>
                                    <option value="702">702</option>
                                    <option value="703">703</option>
                                    <option value="801">801</option>
                                    <option value="802">802</option>
                                    <option value="803">803</option>
                                    <option value="901">901</option>
                                    <option value="902">902</option>
                                    <option value="903">903</option>
                                    <option value="1001">1001</option>
                                    <option value="1002">1002</option>
                                    <option value="1003">1003</option>
                                    <option value="1101">1101</option>
                                    <option value="1102">1102</option>
                                    <option value="1103">1103</option>
                                </select>
                            </div>
                        </div>

                        <div class="grupo">
                            <label for="edad">Edad:</label>
                            <input type="number" name="edad" id="edad"
                                value="<?php echo htmlspecialchars(
                                    (string) $edadUsuario,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>"
                                min="5" max="99" required>
                        </div>

                        <hr style="border:0;border-top:1px solid #eee;margin:15px 0;">

                        <div class="grupo">
                            <label for="nombre_objeto">Nombre del Objeto:</label>
                            <input type="text" name="nombre_objeto"
                                id="nombre_objeto"
                                placeholder="Ej: Chaqueta, Maleta, Cartuchera"
                                required>
                        </div>

                        <div class="grupo">
                            <label for="lugar">Lugar del Suceso:</label>
                            <input type="text" name="lugar" id="lugar"
                                placeholder="Ej: Patio central, Salón 201, Cafetería"
                                required>
                        </div>

                        <!-- MAPA INTERACTIVO -->
                        <div class="panel-mapa">
                            <h3>📍 Ubicación en el plano del colegio</h3>
                            <p>
                                Selecciona el piso y pulsa sobre el plano
                                para señalar dónde ocurrió el suceso.
                            </p>

                            <div class="grupo">
                                <label for="pisoMapa">Piso del colegio:</label>
                                <select id="pisoMapa" name="piso_mapa" required>
                                    <option value="">Selecciona un piso</option>
                                    <option value="Primer piso">Primer piso</option>
                                    <option value="Segundo piso">Segundo piso</option>
                                    <option value="Tercer piso">Tercer piso</option>
                                </select>
                            </div>

                            <div id="mapaColegio" class="mapa-colegio">
                                <img id="imagenMapaColegio"
                                    src="../uploads/mapas/primer_piso.png"
                                    alt="Plano del colegio">
                                <span id="puntoMapa" class="punto-mapa"></span>
                            </div>

                            <input type="hidden" name="coordenada_x"
                                id="coordenadaX">
                            <input type="hidden" name="coordenada_y"
                                id="coordenadaY">

                            <div id="textoUbicacionMapa"
                                class="texto-ubicacion-mapa">
                                Selecciona un piso y marca un punto en el plano.
                            </div>
                        </div>

                        <div class="grupo">
                            <label for="fecha_suceso">Fecha:</label>
                            <input type="date" name="fecha_suceso"
                                id="fecha_suceso"
                                value="<?php echo date('Y-m-d'); ?>" required>
                        </div>

                        <div class="grupo">
                            <label for="descripcion">Descripción del Objeto:</label>
                            <textarea name="descripcion" id="descripcion"
                                rows="3"
                                placeholder="Indica detalles como color, marcas, contenido..."
                                required></textarea>
                        </div>
                    </div>

                    <div class="panel-fotografia">
                        <div class="icono-foto">📷</div>
                        <label for="imagen">Fotografía del objeto</label>
                        <p>Selecciona una imagen para acompañar tu reporte.</p>

                        <input type="file" name="imagen" id="imagen"
                            accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp">

                        <small>JPG, JPEG, PNG o WEBP.</small>

                        <img id="vistaPreviaFoto" class="vista-previa"
                            alt="Vista previa de la fotografía">

                        <p id="textoFoto">
                            Todavía no has seleccionado una fotografía.
                        </p>
                    </div>
                </div>

                <button type="submit" class="btn-guardar">
                    Enviar Reporte
                </button>

                <button type="button" onclick="ocultarFormulario()"
                    style="width:100%;margin-top:8px;padding:10px;border:none;background:#eee;border-radius:8px;cursor:pointer;">
                    Cancelar
                </button>
            </form>
        </div>
    </div>

    <!-- Ventana emergente para reclamar -->
    <div id="modalReclamo" class="modal-reclamo"
        role="dialog" aria-modal="true"
        aria-labelledby="tituloModalReclamo">

        <div class="contenido-reclamo">
            <h2 id="tituloModalReclamo">📋 Reclamar objeto</h2>

            <p id="nombreObjetoReclamo">
                Completa tus datos para solicitar el objeto.
            </p>

            <div id="mensajeReclamo" class="mensaje-reclamo"
                role="alert" aria-live="polite"></div>

            <form id="formularioReclamo">
                <div class="campo-reclamo">
                    <label for="nombreApellidoReclamo">Nombre y apellido *</label>
                    <input type="text" id="nombreApellidoReclamo"
                        name="nombre_apellido" maxlength="100"
                        autocomplete="name" required>
                </div>

                <div class="campo-reclamo">
                    <label for="cursoReclamo">Curso *</label>
                    <input type="text" id="cursoReclamo"
                        name="curso" maxlength="20" required>
                </div>

                <div class="campo-reclamo">
                    <label for="tipoDocumentoReclamo">Tipo de documento *</label>
                    <select id="tipoDocumentoReclamo"
                        name="tipo_documento" required>
                        <option value="">Selecciona tu documento</option>
                        <option value="TI">Tarjeta de identidad (TI)</option>
                        <option value="CC">Cédula de ciudadanía (CC)</option>
                        <option value="CE">Cédula de extranjería (CE)</option>
                        <option value="Otro">Otro</option>
                    </select>
                </div>

                <div class="campo-reclamo">
                    <label for="numeroDocumentoReclamo">Número de documento *</label>
                    <input type="text" id="numeroDocumentoReclamo"
                        name="numero_documento" inputmode="numeric"
                        pattern="[0-9]{5,20}" minlength="5"
                        maxlength="20" autocomplete="off" required>
                </div>

                <button type="submit" id="btnEnviarReclamo"
                    class="btn-enviar-reclamo">
                    Enviar reclamación
                </button>

                <button type="button" id="btnCancelarReclamo"
                    class="btn-cancelar-reclamo">
                    Cancelar
                </button>
            </form>
        </div>
    </div>

    <!-- Galería de objetos -->
    <section id="galeriaWrapper" class="galeria-wrapper">
        <h2 class="titulo-galeria">Imágenes de Objetos Encontrados</h2>

        <p class="texto-galeria">
            Consulta las fotografías de los objetos encontrados
            en el Colegio Técnico Palermo.
        </p>

        <div id="galeria" class="galeria">
            <p class="estado-galeria">
                Presiona Imágenes para consultar los reportes.
            </p>
        </div>

        <button type="button" class="btn-cerrar-galeria"
            onclick="ocultarImagenes()">
            Cerrar imágenes
        </button>
    </section>

    <!-- Panel del usuario -->
    <div class="card-usuario-grande">
        <div class="header-panel">
            <div>
                <h2 class="saludo-titulo">
                    ¡Hola,
                    <?php echo htmlspecialchars(
                        (string) $nombreUsuario,
                        ENT_QUOTES,
                        'UTF-8'
                    ); ?>!
                </h2>
                <span class="saludo-subtitulo">Sesión Activa</span>
            </div>

            <a href="../index.php?logout=1" class="btn-logout">
                Cerrar Sesión
            </a>
        </div>

        <div class="mensaje-confianza">
            Puedes confiar plenamente en nosotras.
            Estamos aquí para ayudarte a reportar y encontrar
            tus objetos perdidos de forma rápida, segura y transparente.
            ¡Cuenta con nuestro apoyo en cada paso! ✨
        </div>
    </div>

    <div class="footer-seccion">
        <h1 class="titulo-palermo">
            Reportes Palermo <span class="corazon-icon">♡</span>
        </h1>

        <p class="mensaje-institucional">
            En el Colegio Técnico Palermo, entendemos que la gestión
            de objetos perdidos es un reflejo de nuestra ética institucional.
            Nos dedicamos a recuperar pertenencias con la máxima transparencia
            y respeto, garantizando que cada estudiante y docente recupere lo suyo
            con la tranquilidad que merece.
        </p>
    </div>

    <script>
        function mostrarFormulario(tipo) {
            document.getElementById('galeriaWrapper').classList.remove('active');
            document.getElementById('modalReclamo').classList.remove('visible');
            document.getElementById('boxFormulario').classList.add('active');

            document.getElementById('inputTipoReporte').value = tipo;
            document.getElementById('formTitulo').innerText =
                'Reportar Objeto ' + tipo;

            limpiarVistaPrevia();
            verificarRolForm();

            document.getElementById('boxFormulario').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }

        function ocultarFormulario() {
            document.getElementById('boxFormulario').classList.remove('active');
        }

        function verificarRolForm() {
            const rol = document.getElementById('rolFormInput').value;
            const box = document.getElementById('boxCursoForm');
            const grado = document.getElementById('gradoFormInput');
            const curso = document.getElementById('cursoFormInput');

            if (rol === 'Estudiante') {
                box.style.display = 'flex';
                grado.required = true;
                curso.required = true;
            } else {
                box.style.display = 'none';
                grado.required = false;
                curso.required = false;
            }
        }

        function limpiarVistaPrevia() {
            const campo = document.getElementById('imagen');
            const vista = document.getElementById('vistaPreviaFoto');
            const texto = document.getElementById('textoFoto');

            campo.value = '';
            vista.removeAttribute('src');
            vista.style.display = 'none';
            texto.textContent = 'Todavía no has seleccionado una fotografía.';
        }

        document.getElementById('imagen').addEventListener('change', function () {
            const archivo = this.files[0];
            const vista = document.getElementById('vistaPreviaFoto');
            const texto = document.getElementById('textoFoto');

            vista.removeAttribute('src');
            vista.style.display = 'none';

            if (!archivo) {
                texto.textContent = 'Todavía no has seleccionado una fotografía.';
                return;
            }

            if (!['image/jpeg', 'image/png', 'image/webp'].includes(archivo.type)) {
                alert('Selecciona una imagen JPG, JPEG, PNG o WEBP.');
                this.value = '';
                texto.textContent = 'Todavía no has seleccionado una fotografía.';
                return;
            }

            if (archivo.size > 5 * 1024 * 1024) {
                alert('La imagen no debe superar los 5 MB.');
                this.value = '';
                texto.textContent = 'Todavía no has seleccionado una fotografía.';
                return;
            }

            const lector = new FileReader();

            lector.onload = function (evento) {
                vista.src = evento.target.result;
                vista.style.display = 'block';
                texto.textContent = archivo.name;
            };

            lector.readAsDataURL(archivo);
        });

        function mostrarImagenes() {
            document.getElementById('boxFormulario').classList.remove('active');
            document.getElementById('modalReclamo').classList.remove('visible');
            document.getElementById('galeriaWrapper').classList.add('active');

            cargarImagenes();

            document.getElementById('galeriaWrapper').scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }

        function ocultarImagenes() {
            document.getElementById('galeriaWrapper').classList.remove('active');
        }

        async function cargarImagenes() {
            const galeria = document.getElementById('galeria');
            galeria.innerHTML =
                '<p class="estado-galeria">Cargando objetos encontrados...</p>';

            try {
                const respuesta = await fetch('../procesos/obtenerImagenes.php');

                if (!respuesta.ok) {
                    throw new Error('No se pudo consultar la galería.');
                }

                const objetos = await respuesta.json();
                galeria.innerHTML = '';

                if (!Array.isArray(objetos)) {
                    throw new Error('La respuesta de la galería no es válida.');
                }

                const encontrados = objetos.filter(objeto =>
                    String(objeto.tipo_reporte || '').toLowerCase() === 'encontrado'
                );

                if (encontrados.length === 0) {
                    galeria.innerHTML =
                        '<p class="estado-galeria">Todavía no hay objetos encontrados registrados.</p>';
                    return;
                }

                encontrados.forEach(objeto => {
                    const tarjeta = document.createElement('article');
                    tarjeta.className = 'tarjeta-objeto';

                    if (objeto.imagen) {
                        const imagen = document.createElement('img');
                        imagen.src = objeto.imagen;
                        imagen.alt = objeto.nombre_objeto || 'Fotografía del objeto';

                        imagen.onerror = function () {
                            this.style.display = 'none';
                            const aviso = document.createElement('div');
                            aviso.className = 'sin-fotografia';
                            aviso.textContent = 'No se pudo cargar la fotografía.';
                            tarjeta.insertBefore(aviso, this);
                        };

                        tarjeta.appendChild(imagen);
                    } else {
                        const sinFoto = document.createElement('div');
                        sinFoto.className = 'sin-fotografia';
                        sinFoto.textContent = 'Este objeto no tiene fotografía.';
                        tarjeta.appendChild(sinFoto);
                    }

                    const contenido = document.createElement('div');
                    contenido.className = 'contenido-objeto';

                    const nombre = document.createElement('h3');
                    nombre.textContent = objeto.nombre_objeto || 'Objeto sin nombre';
                    contenido.appendChild(nombre);

                    const etiqueta = document.createElement('span');
                    etiqueta.className = 'tipo-objeto tipo-encontrado';
                    etiqueta.textContent = 'Objeto encontrado';
                    contenido.appendChild(etiqueta);

                    const lugar = document.createElement('p');
                    lugar.textContent = 'Lugar: ' + (objeto.lugar || 'No especificado');
                    contenido.appendChild(lugar);

                    const descripcion = document.createElement('p');
                    descripcion.textContent = objeto.descripcion || 'Sin descripción.';
                    contenido.appendChild(descripcion);

                    const boton = document.createElement('button');
                    boton.type = 'button';
                    boton.className = 'btn-reclamar';
                    boton.textContent = 'Reclamar';

                    boton.addEventListener('click', function () {
                        reclamarObjeto(objeto.id, objeto.nombre_objeto);
                    });

                    contenido.appendChild(boton);
                    tarjeta.appendChild(contenido);
                    galeria.appendChild(tarjeta);
                });

            } catch (error) {
                galeria.innerHTML =
                    '<p class="estado-galeria">No se pudieron cargar los objetos. Revisa obtenerImagenes.php.</p>';
                console.error(error);
            }
        }

        let idObjetoSeleccionado = null;

        function reclamarObjeto(id, nombre) {
            if (!id) {
                alert('No se pudo identificar el objeto.');
                return;
            }

            idObjetoSeleccionado = id;

            document.getElementById('nombreObjetoReclamo').textContent =
                'Objeto seleccionado: ' + (nombre || 'Objeto encontrado') +
                '. Completa tus datos para enviar la solicitud.';

            document.getElementById('formularioReclamo').reset();

            const mensaje = document.getElementById('mensajeReclamo');
            mensaje.textContent = '';
            mensaje.classList.remove('visible');

            document.getElementById('modalReclamo').classList.add('visible');
            document.getElementById('nombreApellidoReclamo').focus();
        }

        document.getElementById('nombreApellidoReclamo')
            .addEventListener('input', function () {
                this.value = this.value.replace(/[^\p{L}\s]/gu, '');
            });

        document.getElementById('numeroDocumentoReclamo')
            .addEventListener('input', function () {
                this.value = this.value.replace(/[^0-9]/g, '');
            });

        document.getElementById('btnCancelarReclamo')
            .addEventListener('click', function () {
                document.getElementById('modalReclamo').classList.remove('visible');
                document.getElementById('formularioReclamo').reset();
                idObjetoSeleccionado = null;
            });

        function mostrarErrorReclamo(texto) {
            const mensaje = document.getElementById('mensajeReclamo');
            mensaje.textContent = texto;
            mensaje.classList.add('visible');
        }

        document.getElementById('formularioReclamo')
            .addEventListener('submit', async function (evento) {
                evento.preventDefault();

                const formulario = this;
                const mensaje = document.getElementById('mensajeReclamo');
                const boton = document.getElementById('btnEnviarReclamo');

                const nombre = document.getElementById('nombreApellidoReclamo').value.trim();
                const curso = document.getElementById('cursoReclamo').value.trim();
                const tipoDocumento = document.getElementById('tipoDocumentoReclamo').value;
                const numeroDocumento = document.getElementById('numeroDocumentoReclamo').value.trim();

                mensaje.textContent = '';
                mensaje.classList.remove('visible');

                if (!nombre || !curso || !tipoDocumento || !numeroDocumento) {
                    mostrarErrorReclamo('Debes completar todos los campos obligatorios.');
                    return;
                }

                if (!/^[\p{L}]+(?:\s+[\p{L}]+)*$/u.test(nombre)) {
                    mostrarErrorReclamo('Escribe un nombre y apellido válidos.');
                    return;
                }

                if (!/^[\p{L}\p{N} -]+$/u.test(curso)) {
                    mostrarErrorReclamo('Escribe un curso válido, por ejemplo 1101.');
                    return;
                }

                if (!['TI', 'CC', 'CE', 'Otro'].includes(tipoDocumento)) {
                    mostrarErrorReclamo('Selecciona un tipo de documento válido.');
                    return;
                }

                if (!/^[0-9]{5,20}$/.test(numeroDocumento)) {
                    mostrarErrorReclamo('El documento debe tener entre 5 y 20 dígitos.');
                    return;
                }

                if (!idObjetoSeleccionado) {
                    mostrarErrorReclamo('No se ha seleccionado ningún objeto.');
                    return;
                }

                const datos = new URLSearchParams();
                datos.append('id', idObjetoSeleccionado);
                datos.append('nombre_apellido', nombre);
                datos.append('curso', curso);
                datos.append('tipo_documento', tipoDocumento);
                datos.append('numero_documento', numeroDocumento);

                boton.disabled = true;
                boton.textContent = 'Enviando...';

                try {
                    const respuesta = await fetch('../procesos/reclamar.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                        },
                        body: datos.toString()
                    });

                    const resultado = await respuesta.json();

                    if (!respuesta.ok || !resultado.success) {
                        throw new Error(
                            resultado.error ||
                            resultado.mensaje ||
                            'No se pudo registrar la reclamación.'
                        );
                    }

                    alert(resultado.mensaje || '¡Reclamación registrada correctamente!');

                    document.getElementById('modalReclamo').classList.remove('visible');
                    formulario.reset();
                    idObjetoSeleccionado = null;

                } catch (error) {
                    mostrarErrorReclamo(
                        error.message || 'Ocurrió un error al enviar la reclamación.'
                    );
                } finally {
                    boton.disabled = false;
                    boton.textContent = 'Enviar reclamación';
                }
            });

        document.addEventListener('keydown', function (evento) {
            if (evento.key === 'Escape') {
                document.getElementById('modalReclamo').classList.remove('visible');
                idObjetoSeleccionado = null;
            }
        });

        /* Lógica del mapa */
        const selectorPisoMapa = document.getElementById('pisoMapa');
        const mapaColegio = document.getElementById('mapaColegio');
        const imagenMapaColegio = document.getElementById('imagenMapaColegio');
        const puntoMapa = document.getElementById('puntoMapa');
        const coordenadaX = document.getElementById('coordenadaX');
        const coordenadaY = document.getElementById('coordenadaY');
        const textoUbicacionMapa = document.getElementById('textoUbicacionMapa');

        let ubicacionMapaSeleccionada = false;

        function cambiarPlanoColegio() {
            const piso = selectorPisoMapa.value;

            if (!piso) {
                imagenMapaColegio.src = '../uploads/mapas/primer_piso.png';
            } else if (piso === 'Primer piso') {
                imagenMapaColegio.src = '../uploads/mapas/primer_piso.png';
            } else {
                imagenMapaColegio.src = '../uploads/mapas/segundo_tercer_piso.png';
            }

            puntoMapa.classList.remove('visible');
            coordenadaX.value = '';
            coordenadaY.value = '';
            ubicacionMapaSeleccionada = false;

            textoUbicacionMapa.textContent = piso
                ? 'Pulsa sobre el plano para marcar la ubicación.'
                : 'Selecciona un piso y marca un punto en el plano.';
        }

        selectorPisoMapa.addEventListener('change', cambiarPlanoColegio);

        mapaColegio.addEventListener('click', function (evento) {
            if (!selectorPisoMapa.value) {
                alert('Primero selecciona el piso del colegio.');
                return;
            }

            if (!imagenMapaColegio.complete || !imagenMapaColegio.naturalWidth) {
                alert('No se ha cargado el plano. Revisa la carpeta uploads/mapas.');
                return;
            }

            const rect = mapaColegio.getBoundingClientRect();
            const x = ((evento.clientX - rect.left) / rect.width) * 100;
            const y = ((evento.clientY - rect.top) / rect.height) * 100;

            const porcentajeX = Math.max(0, Math.min(100, x));
            const porcentajeY = Math.max(0, Math.min(100, y));

            puntoMapa.style.left = porcentajeX + '%';
            puntoMapa.style.top = porcentajeY + '%';
            puntoMapa.classList.add('visible');

            coordenadaX.value = porcentajeX.toFixed(2);
            coordenadaY.value = porcentajeY.toFixed(2);
            ubicacionMapaSeleccionada = true;

            textoUbicacionMapa.textContent =
                'Piso: ' + selectorPisoMapa.value +
                '. Coordenada X: ' + porcentajeX.toFixed(2) +
                ' %. Coordenada Y: ' + porcentajeY.toFixed(2) + ' %.';
        });

        document.getElementById('formReporte')
            .addEventListener('submit', function (evento) {
                if (!selectorPisoMapa.value || !ubicacionMapaSeleccionada) {
                    evento.preventDefault();
                    alert('Selecciona el piso y marca el punto rojo en el plano.');

                    selectorPisoMapa.scrollIntoView({
                        behavior: 'smooth',
                        block: 'center'
                    });
                }
            });

        verificarRolForm();
    </script>
</body>
</html>
