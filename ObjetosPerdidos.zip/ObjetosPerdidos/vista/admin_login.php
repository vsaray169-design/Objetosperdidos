<?php
session_start();

if (isset($_SESSION['admin'])) {
    header('Location: listaEstudiante.php');
    exit();
}

$error = isset($_GET['error']) ? htmlspecialchars($_GET['error'], ENT_QUOTES, 'UTF-8') : '';
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceso Administrativo - Reportes Palermo</title>
    <style>
        :root {
            --azul: #72B4EB;
            --beige: #F3E9D7;
            --oscuro: #333333;
        }
        body { 
            font-family: Arial, sans-serif; 
            background-color: var(--beige); 
            margin: 0; 
            padding: 40px 20px; 
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            box-sizing: border-box;
        }
        .card-admin {
            width: 100%;
            max-width: 420px;
            background: white;
            padding: 35px 30px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.08);
            text-align: center;
        }
        .titulo {
            font-family: Georgia, 'Times New Roman', serif;
            font-size: 1.8rem;
            color: #112233;
            margin-bottom: 8px;
        }
        .subtitulo {
            color: #666;
            font-size: 0.9rem;
            margin-bottom: 25px;
        }
        .grupo {
            margin-bottom: 16px;
            text-align: left;
        }
        label {
            display: block;
            font-weight: bold;
            margin-bottom: 6px;
            font-size: 0.88rem;
            color: #444;
        }
        input {
            width: 100%;
            padding: 11px 14px;
            border: 1px solid #ddd;
            border-radius: 10px;
            box-sizing: border-box;
            font-size: 0.95rem;
            background-color: #fafafa;
        }
        input:focus {
            outline: none;
            border-color: var(--azul);
            background-color: white;
        }
        .btn-submit {
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 12px;
            font-weight: bold;
            font-size: 1rem;
            cursor: pointer;
            color: white;
            background-color: var(--oscuro);
            margin-top: 10px;
            transition: background 0.2s ease;
        }
        .btn-submit:hover {
            background-color: #111;
        }
        .alerta-error {
            background-color: #FFEBEE;
            color: #C62828;
            padding: 12px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-size: 0.9rem;
        }
        .enlace-volver {
            display: inline-block;
            margin-top: 20px;
            color: #777;
            text-decoration: none;
            font-size: 0.88rem;
        }
        .enlace-volver:hover {
            color: #222;
        }
    </style>
</head>
<body>

<div class="card-admin">
    <h1 class="titulo">Módulo Administrativo 🔑</h1>
    <p class="subtitulo">Ingresa con tu usuario de administrador</p>

    <?php if ($error): ?>
        <div class="alerta-error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form action="../logica/validarAdministrador.php" method="POST">
        <div class="grupo">
            <label for="usuario">Nombre / Usuario:</label>
            <input type="text" id="usuario" name="usuario" placeholder="Ej: reporte objetos" required autocomplete="username">
        </div>

        <div class="grupo">
            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" placeholder="••••••••" required autocomplete="current-password">
        </div>

        <button type="submit" class="btn-submit">Ingresar como Administrador</button>
    </form>

    <a href="../index.php" class="enlace-volver">&larr; Volver al inicio</a>
</div>

</body>
</html>