<!-- Campos de Grado y Curso para Estudiantes -->
            <div id="campos-estudiante" style="display: flex; gap: 10px;">
                <div style="flex: 1;">
                    <label>Grado:</label>
                    <select name="grado">
                        <option value="">Seleccionar...</option>
                        <option value="Sexto">6°</option>
                        <option value="Septimo">7°</option>
                        <option value="Octavo">8°</option>
                        <option value="Noveno">9°</option>
                        <option value="Decimo">10°</option>
                        <option value="Once">11°</option>
                    </select>
                </div>
                <div style="flex: 1;">
                    <label>Curso / Salón:</label>
                    <input type="text" name="curso" placeholder="Ej. 601, 1102">
                </div>
            </div>