
<?php
session_start();

require_once __DIR__ . '/../config/conexionBDD.php';

// Verificar la sesión del administrador
if (!isset($_SESSION['admin']) && !isset($_SESSION['usuario'])) {
    header('Location: admin_login.php');
    exit();
}

$mensaje = '';

function escapar($valor) {
    return htmlspecialchars((string)($valor ?? ''), ENT_QUOTES, 'UTF-8');
}

// Corregir la ruta de las fotografías
function mostrarImagen($ruta) {
    if (empty($ruta)) {
        return '';
    }

    $ruta = trim(str_replace('\\', '/', (string)$ruta));

    // Si la imagen tiene una dirección web completa
    if (preg_match('~^https?://~i', $ruta)) {
        return escapar($ruta);
    }

    // Obtener el nombre del archivo
    $nombreArchivo = basename($ruta);

    // Ruta física de la imagen en el proyecto
    $rutaFisica = __DIR__ . '/../uploads/objetos/' . $nombreArchivo;

    // Ruta que utilizará el navegador
    $rutaWeb = '../uploads/objetos/' . rawurlencode($nombreArchivo);

    if (is_file($rutaFisica)) {
        return escapar($rutaWeb);
    }

    // Intentar utilizar la ruta original si incluye uploads/
    $ruta = ltrim($ruta, '/');

    if (strpos($ruta, 'uploads/') === 0) {
        $partes = explode('/', $ruta);
        $partes = array_map('rawurlencode', $partes);

        return escapar('../' . implode('/', $partes));
    }

    return escapar($rutaWeb);
}

// Archivar un reporte encontrado
if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['marcar_encontrado'])
) {
    $idReporte = filter_input(
        INPUT_POST,
        'id_reporte',
        FILTER_VALIDATE_INT
    );

    if ($idReporte) {
        try {
            $stmt = $conexion->prepare(
                "UPDATE reportes
                 SET estado = 'archivado'
                 WHERE id = ?
                 AND LOWER(tipo_reporte) = 'encontrado'"
            );

            $stmt->execute([$idReporte]);

            header(
                'Location: ' . $_SERVER['PHP_SELF'] . '?archivado=1'
            );
            exit();

        } catch (PDOException $e) {
            error_log($e->getMessage());
            $mensaje = 'No fue posible archivar el reporte.';
        }
    }
}

if (isset($_GET['archivado'])) {
    $mensaje = 'El reporte se archivó correctamente.';
}

try {
    // Objetos perdidos activos
    $stmt = $conexion->prepare(
        "SELECT *
         FROM reportes
         WHERE LOWER(tipo_reporte) = 'perdido'
         AND (estado IS NULL OR estado <> 'archivado')
         ORDER BY id DESC"
    );

    $stmt->execute();
    $perdidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Objetos encontrados activos
    $stmt = $conexion->prepare(
        "SELECT *
         FROM reportes
         WHERE LOWER(tipo_reporte) = 'encontrado'
         AND (estado IS NULL OR estado <> 'archivado')
         ORDER BY id DESC"
    );

    $stmt->execute();
    $encontrados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Historial de reportes archivados
    $stmt = $conexion->prepare(
        "SELECT *
         FROM reportes
         WHERE estado = 'archivado'
         ORDER BY id DESC"
    );

    $stmt->execute();
    $archivados = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Solicitudes de reclamación
    $solicitudes = [];
    $errorSolicitudes = '';

    try {
        $stmt = $conexion->prepare(
            "SELECT
                s.id AS solicitud_id,
                s.id_reporte,
                s.nombre_usuario,
                s.fecha_solicitud,
                s.estado AS estado_solicitud,
                r.nombre_objeto,
                r.descripcion,
                r.imagen
             FROM solicitudes_reclamo s
             LEFT JOIN reportes r
                ON r.id = s.id_reporte
             ORDER BY s.id DESC"
        );

        $stmt->execute();
        $solicitudes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (PDOException $e) {
        error_log($e->getMessage());

        $errorSolicitudes =
            'No se pudieron consultar las solicitudes. Verifica que exista la tabla solicitudes_reclamo.';
    }

} catch (PDOException $e) {
    error_log($e->getMessage());

    die(
        'No se pudieron cargar los reportes. Revisa la conexión y la estructura de la base de datos.'
    );
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Panel de Administrador - Reportes Palermo</title>

    <style>
        :root {
            --azul: #72B4EB;
            --beige: #F3E9D7;
            --rosa: #FF9AA2;
            --verde: #CBE8DA;
            --rojo-alerta: #FF6B6B;
            --amarillo-alerta: #FFD93D;
            --naranja-alerta: #FF9F43;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: var(--beige);
            margin: 0;
            padding: 25px;
            color: #333;
        }

        .container {
            max-width: 1400px;
            margin: auto;
            background: white;
            padding: 25px;
            border-radius: 20px;
            box-shadow: 0 8px 25px rgba(0,0,0,.08);
        }

        h1, h2 {
            font-family: Georgia, 'Times New Roman', serif;
            color: #112233;
        }

        .header-admin {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            border-bottom: 2px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }

        .btn-accion {
            padding: 10px 16px;
            border: 0;
            border-radius: 10px;
            font-weight: bold;
            cursor: pointer;
            font-size: .9rem;
            text-decoration: none;
            display: inline-block;
            margin: 3px;
        }

        .btn-reiniciar {
            background: var(--azul);
            color: white;
        }

        .btn-cerrar {
            background: var(--rosa);
            color: #333;
        }

        .btn-verde {
            background: #2E7D32;
            color: white;
        }

        .btn-oculto {
            background: #444;
            color: white;
        }

        .btn-accion:hover {
            opacity: .85;
        }

        .tablas-wrapper {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }

        .tabla-card {
            min-width: 0;
            background: #fafafa;
            border: 1px solid #ddd;
            border-radius: 14px;
            padding: 18px;
            margin-bottom: 20px;
        }

        .tabla-scroll {
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: white;
        }

        th, td {
            padding: 12px;
            text-align: left;
            vertical-align: top;
            border-bottom: 1px solid #eee;
            font-size: .9rem;
        }

        th {
            background: #f0f0f0;
            color: #444;
        }

        .foto {
            width: 110px;
            height: 100px;
            object-fit: contain;
            border-radius: 8px;
            border: 1px solid #ddd;
            background: white;
        }

        .sin-foto {
            color: #777;
            font-style: italic;
        }

        .badge-estado {
            padding: 6px 10px;
            border-radius: 20px;
            font-weight: bold;
            font-size: .8rem;
            display: inline-block;
            background: var(--amarillo-alerta);
            color: #333;
        }

        .estado-pendiente {
            background: var(--amarillo-alerta);
        }

        .estado-archivado {
            background: var(--verde);
        }

        .aviso {
            padding: 12px;
            margin: 15px 0;
            border-radius: 8px;
            background: var(--verde);
        }

        #seccionSecreta {
            display: none;
            margin-top: 25px;
        }

        #seccionSecreta.visible {
            display: block;
        }

        @media (max-width: 900px) {
            .tablas-wrapper {
                grid-template-columns: 1fr;
            }

            body {
                padding: 10px;
            }

            .container {
                padding: 15px;
            }
        }
    </style>
</head>

<body>
<div class="container">

    <div class="header-admin">
        <div>
            <h1>Panel de Control - Reportes Palermo</h1>
            <p>Administración de objetos perdidos, encontrados y reclamaciones.</p>
        </div>

        <div>
            <a href="<?= escapar($_SERVER['PHP_SELF']) ?>"
               class="btn-accion btn-reiniciar">
                Actualizar panel
            </a>

            <a href="admin_login.php?logout=true"
               class="btn-accion btn-cerrar">
                Cerrar sesión
            </a>
        </div>
    </div>

    <?php if ($mensaje !== ''): ?>
        <div class="aviso"><?= escapar($mensaje) ?></div>
    <?php endif; ?>

    <div class="tablas-wrapper">

        <!-- OBJETOS PERDIDOS -->
        <div class="tabla-card">
            <h2>📦 Objetos perdidos</h2>

            <div class="tabla-scroll">
                <table>
                    <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Objeto e información</th>
                        <th>Estado</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php if (count($perdidos) > 0): ?>
                        <?php foreach ($perdidos as $row): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($row['imagen'])): ?>
                                        <img
                                            class="foto"
                                            src="<?= mostrarImagen($row['imagen']) ?>"
                                            alt="Imagen del objeto"
                                            onerror="this.style.display='none';"
                                        >
                                    <?php else: ?>
                                        <span class="sin-foto">Sin imagen</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= escapar($row['nombre_objeto'] ?? 'Sin nombre') ?>
                                    </strong><br>

                                    <strong>Descripción:</strong>
                                    <?= escapar($row['descripcion'] ?? 'Sin descripción') ?><br>

                                    <strong>Lugar:</strong>
                                    <?= escapar($row['lugar'] ?? 'No indicado') ?><br>

                                    <strong>Fecha:</strong>
                                    <?= escapar($row['fecha_suceso'] ?? 'No indicada') ?><br>

                                    <strong>Reportado por:</strong>
                                    <?= escapar($row['nombre_reportante'] ?? 'No indicado') ?>
                                </td>

                                <td>
                                    <span class="badge-estado">Perdido</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="3">No hay objetos perdidos activos.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- OBJETOS ENCONTRADOS -->
        <div class="tabla-card">
            <h2>✨ Objetos encontrados</h2>

            <div class="tabla-scroll">
                <table>
                    <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Objeto e información</th>
                        <th>Acción</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php if (count($encontrados) > 0): ?>
                        <?php foreach ($encontrados as $row): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($row['imagen'])): ?>
                                        <img
                                            class="foto"
                                            src="<?= mostrarImagen($row['imagen']) ?>"
                                            alt="Imagen del objeto"
                                            onerror="this.style.display='none';"
                                        >
                                    <?php else: ?>
                                        <span class="sin-foto">Sin imagen</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= escapar($row['nombre_objeto'] ?? 'Sin nombre') ?>
                                    </strong><br>

                                    <strong>Descripción:</strong>
                                    <?= escapar($row['descripcion'] ?? 'Sin descripción') ?><br>

                                    <strong>Lugar:</strong>
                                    <?= escapar($row['lugar'] ?? 'No indicado') ?><br>

                                    <strong>Fecha:</strong>
                                    <?= escapar($row['fecha_suceso'] ?? 'No indicada') ?><br>

                                    <strong>Reportado por:</strong>
                                    <?= escapar($row['nombre_reportante'] ?? 'No indicado') ?>
                                </td>

                                <td>
                                    <span class="badge-estado">Encontrado</span>

                                    <form
                                        method="POST"
                                        onsubmit="return confirm('¿Quieres archivar este reporte?');"
                                    >
                                        <input
                                            type="hidden"
                                            name="id_reporte"
                                            value="<?= (int)$row['id'] ?>"
                                        >

                                        <button
                                            type="submit"
                                            name="marcar_encontrado"
                                            class="btn-accion btn-verde"
                                        >
                                            Archivar reporte
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="3">No hay objetos encontrados activos.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- SOLICITUDES DE RECLAMACIÓN -->
    <div class="tabla-card">
        <h2>🙋 Solicitudes de reclamación</h2>

        <p>
            Aquí aparecen las solicitudes enviadas al pulsar «Reclamar» en la galería.
        </p>

        <?php if ($errorSolicitudes !== ''): ?>
            <div class="aviso"><?= escapar($errorSolicitudes) ?></div>

        <?php else: ?>
            <div class="tabla-scroll">
                <table>
                    <thead>
                    <tr>
                        <th>Imagen</th>
                        <th>Objeto</th>
                        <th>Solicitante</th>
                        <th>Fecha de solicitud</th>
                        <th>Estado de solicitud</th>
                    </tr>
                    </thead>

                    <tbody>
                    <?php if (count($solicitudes) > 0): ?>
                        <?php foreach ($solicitudes as $solicitud): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($solicitud['imagen'])): ?>
                                        <img
                                            class="foto"
                                            src="<?= mostrarImagen($solicitud['imagen']) ?>"
                                            alt="Imagen del objeto"
                                            onerror="this.style.display='none';"
                                        >
                                    <?php else: ?>
                                        <span class="sin-foto">Sin imagen</span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <strong>
                                        <?= escapar($solicitud['nombre_objeto'] ?? 'Reporte no disponible') ?>
                                    </strong><br>

                                    <?= escapar($solicitud['descripcion'] ?? 'Sin descripción') ?><br>

                                    ID del reporte:
                                    <?= (int)$solicitud['id_reporte'] ?>
                                </td>

                                <td>
                                    <?= escapar($solicitud['nombre_usuario']) ?>
                                </td>

                                <td>
                                    <?= escapar($solicitud['fecha_solicitud']) ?>
                                </td>

                                <td>
                                    <span class="badge-estado estado-pendiente">
                                        <?= escapar($solicitud['estado_solicitud'] ?? 'Pendiente') ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="5">Todavía no hay solicitudes de reclamación.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <!-- HISTORIAL OCULTO -->
    <div style="text-align:center;">
        <button
            type="button"
            onclick="toggleSeccionSecreta()"
            class="btn-accion btn-oculto"
        >
            🔒 Mostrar historial oculto
        </button>
    </div>

    <div id="seccionSecreta" class="tabla-card">
        <h2>🗄️ Historial oculto de objetos recuperados</h2>

        <p>Los reportes archivados se conservan en la base de datos.</p>

        <div class="tabla-scroll">
            <table>
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Imagen</th>
                    <th>Objeto</th>
                    <th>Descripción</th>
                    <th>Estado</th>
                </tr>
                </thead>

                <tbody>
                <?php if (count($archivados) > 0): ?>
                    <?php foreach ($archivados as $row): ?>
                        <tr>
                            <td><?= (int)$row['id'] ?></td>

                            <td>
                                <?php if (!empty($row['imagen'])): ?>
                                    <img
                                        class="foto"
                                        src="<?= mostrarImagen($row['imagen']) ?>"
                                        alt="Imagen del objeto"
                                        onerror="this.style.display='none';"
                                    >
                                <?php else: ?>
                                    <span class="sin-foto">Sin imagen</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <?= escapar($row['nombre_objeto'] ?? 'Sin nombre') ?>
                            </td>

                            <td>
                                <?= escapar($row['descripcion'] ?? 'Sin descripción') ?>
                            </td>

                            <td>
                                <span class="badge-estado estado-archivado">
                                    Archivado
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php else: ?>
                    <tr>
                        <td colspan="5">No hay reportes archivados.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script>
function toggleSeccionSecreta() {
    const seccion = document.getElementById('seccionSecreta');
    const boton = document.querySelector('.btn-oculto');

    seccion.classList.toggle('visible');

    boton.textContent = seccion.classList.contains('visible')
        ? 'Ocultar historial'
        : '🔒 Mostrar historial oculto';
}
</script>

</body>
</html>

