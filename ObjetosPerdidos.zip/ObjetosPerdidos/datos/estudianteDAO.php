
<?php
require_once __DIR__ . '/../config/conexionBDD.php';

class EstudianteDAO {
    private $conexion;

    public function __construct($db) {
        $this->conexion = $db;
    }

    public function guardarReporte(
        $tipo,
        $nombre,
        $rol,
        $curso,
        $edad,
        $objeto,
        $lugar,
        $fecha,
        $descripcion,
        $imagen = null,
        $pisoMapa = null,
        $coordenadaX = null,
        $coordenadaY = null
    ) {
        $sql = "INSERT INTO reportes (
            tipo_reporte,
            nombre_reportante,
            rol_institucional,
            curso,
            edad,
            nombre_objeto,
            lugar,
            fecha_suceso,
            descripcion,
            imagen,
            piso_mapa,
            coordenada_x,
            coordenada_y
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $this->conexion->prepare($sql);

        return $stmt->execute([
            $tipo,
            $nombre,
            $rol,
            $curso,
            $edad,
            $objeto,
            $lugar,
            $fecha,
            $descripcion,
            $imagen,
            $pisoMapa,
            $coordenadaX,
            $coordenadaY
        ]);
    }
}
?>

