<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';

iniciarSesionSegura();

header('Location: ../vista/listaEstudiante.php');
exit();
?>