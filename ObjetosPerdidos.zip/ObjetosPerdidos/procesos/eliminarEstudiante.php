<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';
require_once __DIR__ . '/../config/conexionBDD.php';
require_once __DIR__ . '/../datos/estudianteDAO.php';

iniciarSesionSegura();

$id = $_GET['id'] ?? null;

if ($id) {
    eliminarObjetoDAO($conexion, $id);
}

header('Location: ../vista/listaEstudiante.php?mensaje=' . urlencode('Reporte eliminado correctamente'));
exit();
?>