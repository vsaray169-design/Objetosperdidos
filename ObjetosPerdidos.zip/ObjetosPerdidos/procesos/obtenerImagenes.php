

<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';
require_once __DIR__ . '/../config/conexionBDD.php';

iniciarSesionSegura();

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['usuario'])) {
    http_response_code(401);
    echo json_encode([
        'error' => 'Debes iniciar sesión para consultar los objetos.'
    ]);
    exit();
}

try {
    $sql = "SELECT
                r.id,
                r.tipo_reporte,
                r.nombre_objeto,
                r.lugar,
                r.descripcion,
                r.imagen
            FROM reportes r
            WHERE r.tipo_reporte = ?
              AND NOT EXISTS (
                  SELECT 1
                  FROM solicitudes_reclamo sr
                  WHERE sr.id_reporte = r.id
                    AND sr.estado = 'Atendida'
              )
            ORDER BY r.id DESC";

    $stmt = $conexion->prepare($sql);
    $stmt->execute(['Encontrado']);

    $objetos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($objetos as &$objeto) {
        if (!empty($objeto['imagen'])) {
            $ruta = str_replace('\\', '/', $objeto['imagen']);
            $objeto['imagen'] = '../' . ltrim($ruta, '/');
        } else {
            $objeto['imagen'] = null;
        }
    }

    unset($objeto);

    echo json_encode(
        $objetos,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );

} catch (Throwable $e) {
    error_log($e->getMessage());

    http_response_code(500);
    echo json_encode([
        'error' => 'No fue posible consultar los objetos encontrados.'
    ]);
}
