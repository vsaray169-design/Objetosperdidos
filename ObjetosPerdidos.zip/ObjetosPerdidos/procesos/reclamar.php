
<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';
require_once __DIR__ . '/../config/conexionBDD.php';

iniciarSesionSegura();

header('Content-Type: application/json; charset=utf-8');

function responderJSON(int $codigo, array $datos): void
{
    http_response_code($codigo);

    echo json_encode(
        $datos,
        JSON_UNESCAPED_UNICODE
    );

    exit();
}

// Verificar que el usuario haya iniciado sesión.
if (!isset($_SESSION['usuario'])) {
    responderJSON(401, [
        'error' => 'Debes iniciar sesión para reclamar un objeto.'
    ]);
}

// Solo se aceptan solicitudes POST.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');

    responderJSON(405, [
        'error' => 'Método no permitido.'
    ]);
}

// Obtener el ID del objeto.
$idObjeto = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if (!$idObjeto || $idObjeto < 1) {
    responderJSON(400, [
        'error' => 'El objeto seleccionado no es válido.'
    ]);
}

// Obtener los datos del formulario.
$nombreReclamante = trim(
    (string) ($_POST['nombre_apellido'] ?? '')
);

$cursoReclamante = trim(
    (string) ($_POST['curso'] ?? '')
);

$tipoDocumento = trim(
    (string) ($_POST['tipo_documento'] ?? '')
);

$numeroDocumento = trim(
    (string) ($_POST['numero_documento'] ?? '')
);

// Comprobar que todos los campos estén completos.
if (
    $nombreReclamante === '' ||
    $cursoReclamante === '' ||
    $tipoDocumento === '' ||
    $numeroDocumento === ''
) {
    responderJSON(400, [
        'error' => 'Todos los campos son obligatorios. Completa el formulario.'
    ]);
}

// Validar nombre y apellido.
// Permite letras, tildes, ñ y espacios.
// No permite números ni otros caracteres.
if (
    !preg_match(
        "/^[\\p{L}]+(?: +[\\p{L}]+)*$/u",
        $nombreReclamante
    )
) {
    responderJSON(400, [
        'error' => 'El nombre y apellido solo deben contener letras y espacios. No escribas números.'
    ]);
}

if (mb_strlen($nombreReclamante, 'UTF-8') > 100) {
    responderJSON(400, [
        'error' => 'El nombre y apellido no puede superar los 100 caracteres.'
    ]);
}

// Validar el curso.
if (
    mb_strlen($cursoReclamante, 'UTF-8') > 20 ||
    !preg_match('/^[\p{L}\p{N} -]+$/u', $cursoReclamante)
) {
    responderJSON(400, [
        'error' => 'Escribe un curso válido, por ejemplo: 10-02.'
    ]);
}

// Validar el tipo de documento.
$documentosPermitidos = ['TI', 'CC', 'CE', 'Otro'];

if (!in_array($tipoDocumento, $documentosPermitidos, true)) {
    responderJSON(400, [
        'error' => 'Selecciona un tipo de documento válido.'
    ]);
}

// Validar el número de documento.
// Solo permite números y exige entre 5 y 20 dígitos.
if (!preg_match('/^[0-9]{5,20}$/', $numeroDocumento)) {
    responderJSON(400, [
        'error' => 'El número de documento debe contener entre 5 y 20 dígitos, sin letras ni espacios.'
    ]);
}

try {
    // Verificar que el objeto exista y sea de tipo Encontrado.
    $consulta = $conexion->prepare(
        "SELECT id, nombre_objeto
         FROM reportes
         WHERE id = ?
           AND tipo_reporte = 'Encontrado'
           AND estado_historial = 'activo'
         LIMIT 1"
    );

    $consulta->execute([$idObjeto]);

    $objeto = $consulta->fetch(PDO::FETCH_ASSOC);

    if (!$objeto) {
        responderJSON(404, [
            'error' => 'El objeto no existe o ya no está disponible para reclamar.'
        ]);
    }

    // Identificar al usuario que inició sesión.
    $usuario = $_SESSION['usuario'];

    if (is_array($usuario)) {
        $nombreUsuario = $usuario['nombre']
            ?? $usuario['usuario']
            ?? null;
    } else {
        $nombreUsuario = $usuario;
    }

    if (
        !is_string($nombreUsuario) ||
        trim($nombreUsuario) === ''
    ) {
        responderJSON(400, [
            'error' => 'No se pudo identificar al usuario. Inicia sesión nuevamente.'
        ]);
    }

    $nombreUsuario = trim($nombreUsuario);

    // Evitar solicitudes pendientes duplicadas
    // del mismo usuario para el mismo objeto.
    $consulta = $conexion->prepare(
        "SELECT id
         FROM solicitudes_reclamo
         WHERE id_reporte = ?
           AND nombre_usuario = ?
           AND estado = 'Pendiente'
         LIMIT 1"
    );

    $consulta->execute([
        $idObjeto,
        $nombreUsuario
    ]);

    if ($consulta->fetch(PDO::FETCH_ASSOC)) {
        responderJSON(409, [
            'error' => 'Ya tienes una solicitud pendiente para este objeto.'
        ]);
    }

    // Guardar la solicitud y los datos del reclamante.
    $consulta = $conexion->prepare(
        "INSERT INTO solicitudes_reclamo
        (
            id_reporte,
            nombre_usuario,
            nombre_reclamante,
            curso_reclamante,
            tipo_documento,
            numero_documento,
            estado
        )
        VALUES (?, ?, ?, ?, ?, ?, 'Pendiente')"
    );

    $consulta->execute([
        $idObjeto,
        $nombreUsuario,
        $nombreReclamante,
        $cursoReclamante,
        $tipoDocumento,
        $numeroDocumento
    ]);

    responderJSON(200, [
        'success' => true,
        'mensaje' => 'Tu reclamación fue registrada correctamente.'
    ]);

} catch (Throwable $e) {
    error_log($e->getMessage());

    responderJSON(500, [
        'error' => 'No se pudo guardar la reclamación. Verifica la conexión y los campos de la base de datos.'
    ]);
}


