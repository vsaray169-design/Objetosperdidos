<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';
require_once __DIR__ . '/../config/conexionBDD.php';
require_once __DIR__ . '/../datos/estudianteDAO.php';

iniciarSesionSegura();

$id            = $_POST['id'] ?? null;
$nombre_objeto = trim($_POST['nombre_objeto'] ?? '');
$lugar         = trim($_POST['lugar'] ?? '');
$fecha_suceso  = $_POST['fecha_suceso'] ?? '';
$descripcion   = trim($_POST['descripcion'] ?? '');

if ($id) {
    actualizarObjetoDAO($conexion, $id, $nombre_objeto, $lugar, $fecha_suceso, $descripcion);
}

header('Location: ../vista/listaEstudiante.php?mensaje=' . urlencode('Reporte actualizado con éxito'));
exit();
?>