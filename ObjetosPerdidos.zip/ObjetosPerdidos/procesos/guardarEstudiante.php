
<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';
require_once __DIR__ . '/../config/conexionBDD.php';
require_once __DIR__ . '/../datos/estudianteDAO.php';

iniciarSesionSegura();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../vista/listaEstudiante.php');
    exit();
}

function volverConMensaje($mensaje) {
    header('Location: ../vista/listaEstudiante.php?mensaje=' .
        urlencode($mensaje));
    exit();
}

$tipo = $_POST['tipo_reporte'] ?? 'Perdido';

if (!in_array($tipo, ['Perdido', 'Encontrado'], true)) {
    volverConMensaje('El tipo de reporte no es válido.');
}

$nombre = trim($_POST['nombre_reportante'] ?? '');
$rol = trim($_POST['rol_institucional'] ?? '');
$curso = trim($_POST['curso'] ?? 'N/A');
$edad = (int) ($_POST['edad'] ?? 0);
$objeto = trim($_POST['nombre_objeto'] ?? '');
$lugar = trim($_POST['lugar'] ?? '');
$fecha = $_POST['fecha_suceso'] ?? '';
$descripcion = trim($_POST['descripcion'] ?? '');

/* Datos de ubicación del mapa */
$pisoMapa = $_POST['piso_mapa'] ?? '';
$coordenadaX = $_POST['coordenada_x'] ?? '';
$coordenadaY = $_POST['coordenada_y'] ?? '';

if (!in_array(
    $pisoMapa,
    ['Primer piso', 'Segundo piso', 'Tercer piso'],
    true
)) {
    volverConMensaje('Selecciona un piso válido en el mapa.');
}

if (
    $coordenadaX === '' ||
    $coordenadaY === '' ||
    !is_numeric($coordenadaX) ||
    !is_numeric($coordenadaY) ||
    (float) $coordenadaX < 0 ||
    (float) $coordenadaX > 100 ||
    (float) $coordenadaY < 0 ||
    (float) $coordenadaY > 100
) {
    volverConMensaje('Marca la ubicación del objeto en el plano.');
}

$coordenadaX = (float) $coordenadaX;
$coordenadaY = (float) $coordenadaY;

if (
    $nombre === '' ||
    $rol === '' ||
    $objeto === '' ||
    $lugar === '' ||
    $descripcion === ''
) {
    volverConMensaje('Completa los campos obligatorios del reporte.');
}

$fechaValida = DateTime::createFromFormat('!Y-m-d', $fecha);

if (
    !$fechaValida ||
    $fechaValida->format('Y-m-d') !== $fecha
) {
    volverConMensaje('La fecha del reporte no es válida.');
}

$rutaImagen = null;
$carpetaImagenes = __DIR__ . '/../uploads/objetos/';

if (
    isset($_FILES['imagen']) &&
    $_FILES['imagen']['error'] !== UPLOAD_ERR_NO_FILE
) {
    if ($_FILES['imagen']['error'] !== UPLOAD_ERR_OK) {
        volverConMensaje('No se pudo subir la imagen. Inténtalo de nuevo.');
    }

    if ($_FILES['imagen']['size'] > 5 * 1024 * 1024) {
        volverConMensaje('La imagen no puede superar los 5 MB.');
    }

    $tipoImagen = (new finfo(FILEINFO_MIME_TYPE))
        ->file($_FILES['imagen']['tmp_name']);

    $tiposPermitidos = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($tiposPermitidos[$tipoImagen])) {
        volverConMensaje('Usa una imagen JPG, PNG o WEBP.');
    }

    if (
        !is_dir($carpetaImagenes) &&
        !mkdir($carpetaImagenes, 0755, true)
    ) {
        volverConMensaje('No se pudo preparar la carpeta de imágenes.');
    }

    $nombreArchivo = bin2hex(random_bytes(16)) . '.' .
        $tiposPermitidos[$tipoImagen];

    if (!move_uploaded_file(
        $_FILES['imagen']['tmp_name'],
        $carpetaImagenes . $nombreArchivo
    )) {
        volverConMensaje('No se pudo guardar la imagen.');
    }

    $rutaImagen = 'uploads/objetos/' . $nombreArchivo;
}

try {
    $dao = new EstudianteDAO($conexion);

    $guardado = $dao->guardarReporte(
        $tipo,
        $nombre,
        $rol,
        $curso,
        $edad,
        $objeto,
        $lugar,
        $fecha,
        $descripcion,
        $rutaImagen,
        $pisoMapa,
        $coordenadaX,
        $coordenadaY
    );

    if (!$guardado && $rutaImagen !== null) {
        @unlink(__DIR__ . '/../' . $rutaImagen);
    }

    $mensaje = $guardado
        ? "¡Reporte de objeto $tipo registrado correctamente!"
        : 'No se pudo guardar el reporte.';

} catch (Throwable $e) {
    if ($rutaImagen !== null) {
        @unlink(__DIR__ . '/../' . $rutaImagen);
    }

    error_log($e->getMessage());
    $mensaje = 'Ocurrió un error al guardar el reporte.';
}

volverConMensaje($mensaje);
?>

