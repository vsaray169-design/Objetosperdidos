<?php
require_once __DIR__ . '/../logica/validarEstudiante.php';

iniciarSesionSegura();

$id = $_GET['id'] ?? null;

if ($id) {
    header('Location: ../vista/formularioEditar.php?id=' . $id);
} else {
    header('Location: ../vista/listaEstudiante.php');
}
exit();
?>